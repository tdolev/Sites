import { useState, useMemo } from "react";

const DARK = {
  bg: "#080B10", surface: "rgba(255,255,255,0.03)", surfaceHover: "rgba(255,255,255,0.06)",
  border: "rgba(255,255,255,0.07)", borderHover: "rgba(255,255,255,0.15)",
  text: "rgba(255,255,255,0.9)", textMuted: "rgba(255,255,255,0.45)",
  textFaint: "rgba(255,255,255,0.25)", textMeta: "rgba(255,255,255,0.35)",
  accent: "#60A5FA", accentBg: "rgba(96,165,250,0.15)", accentBorder: "rgba(96,165,250,0.3)",
  input: "rgba(255,255,255,0.05)", inputBorder: "rgba(255,255,255,0.1)",
  modalBg: "#0F1117", modalBorder: "rgba(255,255,255,0.12)",
  clearBg: "rgba(248,113,113,0.1)", clearBorder: "rgba(248,113,113,0.3)", clearText: "#F87171",
  tagText: "rgba(255,255,255,0.5)", tagBorder: "rgba(255,255,255,0.1)",
  footerBorder: "rgba(255,255,255,0.06)", titleFill: "transparent",
  titleGradient: "linear-gradient(135deg, #fff 0%, rgba(255,255,255,0.5) 100%)",
  bodyText: "rgba(255,255,255,0.7)", sectionBorder: "rgba(255,255,255,0.07)",
  barEmpty: "rgba(255,255,255,0.15)", signalGreen: "#34D399",
};
const LIGHT = {
  bg: "#F1F5F9", surface: "#FFFFFF", surfaceHover: "#EEF2FF",
  border: "#E2E8F0", borderHover: "#CBD5E1",
  text: "#0F172A", textMuted: "#475569", textFaint: "#94A3B8", textMeta: "#64748B",
  accent: "#2563EB", accentBg: "rgba(37,99,235,0.08)", accentBorder: "rgba(37,99,235,0.25)",
  input: "#FFFFFF", inputBorder: "#CBD5E1",
  modalBg: "#FFFFFF", modalBorder: "#E2E8F0",
  clearBg: "rgba(239,68,68,0.08)", clearBorder: "rgba(239,68,68,0.3)", clearText: "#EF4444",
  tagText: "#475569", tagBorder: "#E2E8F0",
  footerBorder: "#E2E8F0", titleFill: "#0F172A", titleGradient: "none",
  bodyText: "#334155", sectionBorder: "#E2E8F0",
  barEmpty: "#E2E8F0", signalGreen: "#059669",
};

const TAG_COLORS_DARK = {
  "Anthropic":"#C084FC","OpenAI":"#34D399","Google":"#60A5FA","Security":"#F87171",
  "Claude Code":"#A78BFA","Infrastructure":"#FB923C","MCP":"#38BDF8","Cursor":"#FBBF24",
  "Enterprise":"#94A3B8","Model Release":"#E879F9","Policy":"#F472B6","JavaScript":"#FCD34D",
};
const TAG_COLORS_LIGHT = {
  "Anthropic":"#7C3AED","OpenAI":"#059669","Google":"#1D4ED8","Security":"#DC2626",
  "Claude Code":"#6D28D9","Infrastructure":"#EA580C","MCP":"#0284C7","Cursor":"#D97706",
  "Enterprise":"#475569","Model Release":"#A21CAF","Policy":"#DB2777","JavaScript":"#B45309",
};

function timeAgo(dateStr) {
  const diffDays = Math.floor((new Date("2026-06-30") - new Date(dateStr)) / 86400000);
  if (diffDays === 0) return "Today";
  if (diffDays === 1) return "Yesterday";
  if (diffDays < 7) return `${diffDays}d ago`;
  if (diffDays < 30) return `${Math.floor(diffDays/7)}w ago`;
  if (diffDays < 365) return `${Math.floor(diffDays/30)}mo ago`;
  return `${Math.floor(diffDays/365)}y ago`;
}
function signalBars(dateStr) {
  const d = Math.floor((new Date("2026-06-30") - new Date(dateStr)) / 86400000);
  if (d < 7) return 4; if (d < 30) return 3; if (d < 90) return 2; return 1;
}

function SignalBars({ bars, color, t }) {
  return (
    <div style={{ display:"flex", alignItems:"flex-end", gap:"2px", height:"14px" }}>
      {[1,2,3,4].map(b => (
        <div key={b} style={{
          width:"3px", height:`${b*3+2}px`, borderRadius:"1px",
          background: b<=bars ? color : t.barEmpty, transition:"background 0.2s",
        }}/>
      ))}
    </div>
  );
}

function TagBadge({ tag, selected, onClick, t, isDark }) {
  const cols = isDark ? TAG_COLORS_DARK : TAG_COLORS_LIGHT;
  const base = cols[tag] || (isDark ? "#94A3B8" : "#475569");
  return (
    <button onClick={onClick} style={{
      padding:"2px 8px", borderRadius:"4px", fontSize:"11px",
      fontFamily:"'JetBrains Mono','Fira Code',monospace", fontWeight:600, letterSpacing:"0.02em",
      border: selected ? `1px solid ${base}` : `1px solid ${t.tagBorder}`,
      background: selected ? `${base}22` : "transparent",
      color: selected ? base : t.tagText,
      cursor: onClick ? "pointer" : "default", transition:"all 0.15s", whiteSpace:"nowrap",
    }}>{tag}</button>
  );
}

function renderBody(body, t) {
  const lines = body.split("\n");
  const out = [];
  let i = 0;
  while (i < lines.length) {
    const ln = lines[i];
    if (ln.startsWith("**") && ln.endsWith("**")) {
      out.push(<h4 key={i} style={{margin:"18px 0 6px",fontSize:"13.5px",fontWeight:700,color:t.text}}>{ln.slice(2,-2)}</h4>);
    } else if (ln.startsWith("- ") || ln.startsWith("• ")) {
      const items = [];
      while (i < lines.length && (lines[i].startsWith("- ")||lines[i].startsWith("• "))) {
        items.push(lines[i].replace(/^[-•] /,""));
        i++;
      }
      out.push(<ul key={`ul${i}`} style={{margin:"6px 0",paddingLeft:"20px"}}>{items.map((it,j)=>(
        <li key={j} style={{fontSize:"13.5px",color:t.bodyText,lineHeight:1.7,marginBottom:"2px"}}>{it}</li>
      ))}</ul>);
      continue;
    } else if (ln.trim()==="") {
      out.push(<div key={i} style={{height:"8px"}}/>);
    } else {
      out.push(<p key={i} style={{margin:"0 0 4px",fontSize:"13.5px",color:t.bodyText,lineHeight:1.75}}>{ln}</p>);
    }
    i++;
  }
  return out;
}

function PostCard({ post, onClick, t, isDark }) {
  const bars = signalBars(post.date);
  const bcs = isDark ? ["#F87171","#FBBF24","#34D399","#60A5FA"] : ["#EF4444","#D97706","#059669","#2563EB"];
  const [hov, setHov] = useState(false);
  return (
    <div onClick={onClick} onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{
        background: hov ? t.surfaceHover : t.surface,
        border:`1px solid ${hov ? t.borderHover : t.border}`,
        borderRadius:"10px", padding:"20px", cursor:"pointer",
        transition:"all 0.15s ease", display:"flex", flexDirection:"column", gap:"12px",
        boxShadow: hov ? (isDark?"0 4px 20px rgba(0,0,0,0.4)":"0 4px 20px rgba(0,0,0,0.08)") : (isDark?"none":"0 1px 4px rgba(0,0,0,0.04)"),
        transform: hov ? "translateY(-2px)" : "translateY(0)",
      }}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:"8px"}}>
        <div style={{fontSize:"22px",lineHeight:1}}>{post.emoji}</div>
        <div style={{display:"flex",alignItems:"center",gap:"8px",marginLeft:"auto"}}>
          <SignalBars bars={bars} color={bcs[bars-1]} t={t}/>
          <span style={{fontSize:"11px",color:t.textMeta,fontFamily:"monospace"}}>{timeAgo(post.date)}</span>
        </div>
      </div>
      <h3 style={{margin:0,fontSize:"14px",fontWeight:700,lineHeight:1.4,color:t.text,fontFamily:"'Inter','Segoe UI',sans-serif",letterSpacing:"-0.01em"}}>{post.title}</h3>
      <p style={{margin:0,fontSize:"12.5px",color:t.textMuted,lineHeight:1.6,display:"-webkit-box",WebkitLineClamp:3,WebkitBoxOrient:"vertical",overflow:"hidden"}}>{post.summary}</p>
      <div style={{display:"flex",flexWrap:"wrap",gap:"4px"}}>
        {post.tags.map(tag=><TagBadge key={tag} tag={tag} t={t} isDark={isDark}/>)}
      </div>
      <div style={{fontSize:"11px",color:t.textFaint,fontFamily:"monospace",marginTop:"auto",paddingTop:"8px",borderTop:`1px solid ${t.sectionBorder}`}}>
        {post.author} · {post.date}
      </div>
    </div>
  );
}

function PostModal({ post, onClose, t, isDark }) {
  if (!post) return null;
  return (
    <div onClick={onClose} style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.6)",backdropFilter:"blur(6px)",zIndex:100,display:"flex",alignItems:"center",justifyContent:"center",padding:"20px"}}>
      <div onClick={e=>e.stopPropagation()} style={{
        background:t.modalBg, border:`1px solid ${t.modalBorder}`,
        borderRadius:"14px", padding:"32px", maxWidth:"660px", width:"100%",
        maxHeight:"85vh", overflowY:"auto", display:"flex", flexDirection:"column", gap:"16px",
        boxShadow:"0 24px 80px rgba(0,0,0,0.3)",
      }}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
          <span style={{fontSize:"28px"}}>{post.emoji}</span>
          <button onClick={onClose} style={{background:"none",border:`1px solid ${t.border}`,color:t.textMuted,cursor:"pointer",borderRadius:"6px",padding:"4px 10px",fontSize:"12px"}}>✕ Close</button>
        </div>
        <h2 style={{margin:0,fontSize:"20px",fontWeight:800,color:t.text,lineHeight:1.3,letterSpacing:"-0.02em"}}>{post.title}</h2>
        <div style={{display:"flex",gap:"10px",alignItems:"center",flexWrap:"wrap"}}>
          <span style={{fontSize:"12px",color:t.textMeta,fontFamily:"monospace"}}>{post.author}</span>
          <span style={{fontSize:"12px",color:t.textMeta,fontFamily:"monospace"}}>{post.date}</span>
          <span style={{fontSize:"11px",background:t.accentBg,color:t.accent,padding:"2px 8px",borderRadius:"4px",fontFamily:"monospace"}}>{timeAgo(post.date)}</span>
        </div>
        <div style={{paddingTop:"8px",borderTop:`1px solid ${t.sectionBorder}`,display:"flex",flexDirection:"column",gap:"2px"}}>
          {renderBody(post.body, t)}
        </div>
        <div style={{display:"flex",flexWrap:"wrap",gap:"6px",paddingTop:"8px",borderTop:`1px solid ${t.sectionBorder}`}}>
          {post.tags.map(tag=><TagBadge key={tag} tag={tag} t={t} isDark={isDark} selected/>)}
        </div>
        {post.link && (
          <a href={post.link} target="_blank" rel="noopener noreferrer" style={{display:"inline-flex",alignItems:"center",gap:"6px",padding:"10px 18px",background:t.accentBg,border:`1px solid ${t.accentBorder}`,borderRadius:"8px",color:t.accent,textDecoration:"none",fontSize:"13px",fontWeight:600}}>
            → Read Original Post
          </a>
        )}
      </div>
    </div>
  );
}
const POSTS = [
  {id:1,date:"2026-06-30",author:"Victor Zhinzherov",tags:["OpenAI","Hardware","Infrastructure"],emoji:"💡",
   title:"OpenAI's Jalapeño Chip: When AI Companies Start Building the Hardware Too",
   summary:"OpenAI announced Jalapeño, its first LLM-optimized inference chip built with Broadcom. AI companies are moving deeper into the full stack — not just models, but the physical infrastructure.",
   body:`OpenAI just announced Jalapeño, its first LLM-optimized inference chip, built together with Broadcom.

The interesting part here is not only that OpenAI is building a chip. The bigger story is that AI companies are moving deeper into the full stack: not just models, not just products, not just APIs, but also the infrastructure that physically runs the models.

As AI usage grows, inference becomes one of the most important bottlenecks in the entire system. Every ChatGPT answer, every Codex task, every API request, every agent workflow, and every enterprise AI feature eventually depends on how fast, reliable, and cost-efficient inference can be at massive scale.

**The basics: training vs inference**

In AI, training is the stage where the model is created — where a model like GPT learns from huge amounts of data, code, language, examples, and patterns.

Inference is the stage where we actually use the model. Every time we ask ChatGPT a question, run a Codex task, or call an AI API, the model needs to process the input and generate an answer. That is the part that happens constantly in real-world usage.

Jalapeño is mainly focused on inference. That matters because inference becomes very expensive and heavy at scale. Every prompt, every response, every agent step requires compute power.

**What is Jalapeño?**

Jalapeño is an AI inference accelerator designed specifically for large language models. Unlike general-purpose accelerators, OpenAI says this chip was designed from scratch around the needs of modern and future LLMs — optimized around model serving patterns, kernels, memory movement, networking, latency, throughput, and power efficiency.

OpenAI also said early testing shows Jalapeño should deliver substantially better performance per watt than current state-of-the-art systems.

**Why inference matters so much**

For developers and companies, inference efficiency directly affects real product experience:
- Faster responses in AI tools
- Lower API costs
- Better availability during high demand
- More room for longer agentic workflows
- More affordable AI features inside products
- Better scalability for enterprise adoption

**The full-stack AI race**

The AI race is no longer only about releasing a smarter model every few months. It is becoming a race to build the entire machine around intelligence: chips, data centers, networking, models, APIs, agents, products, and enterprise workflows.

Jalapeño is OpenAI saying: to scale AI, we cannot only depend on existing hardware. We need infrastructure designed specifically for the way LLMs actually work. If this strategy succeeds, the impact will show up in the tools we use every day: faster AI assistants, cheaper AI APIs, more capable coding agents, and more reliable AI products at scale.`,
   link:"https://openai.com/index/openai-broadcom-jalapeno-inference-chip/"},
  {id:2,date:"2026-06-29",author:"Tamir Tubul",tags:["Policy","Regulation","OpenAI"],emoji:"📌",
   title:"US Gov Asks OpenAI to Stagger GPT-5.6 Release — One Customer at a Time",
   summary:"The Commerce Secretary intervened to stagger GPT-5.6's rollout. Frontier models are starting to look like regulated infrastructure.",
   body:`Worth a read: the US government just asked OpenAI to stagger GPT-5.6's release — shipping it to government-approved customers first, granted one customer at a time.

**Why it matters**

This isn't just an Anthropic thing anymore (their Fable/Mythos models got pulled from the US market earlier this month). Now it's OpenAI too. When a single call from the Commerce Secretary can stall a launch and access is handed out customer-by-customer, the line between "voluntary review" and a federal license gets pretty thin.

**The bigger signal**

Frontier models are starting to be treated like regulated infrastructure. Interestingly, the EU is moving the opposite direction — Parliament just voted to simplify its AI Act and delay the toughest rules to stay competitive.

Feels like the start of a new era where governments want a hand on the release valve.`,
   link:"https://www.axios.com/2026/06/25/trump-administration-openai-gpt-model-release"},
  {id:3,date:"2026-06-25",author:"Tamir Tubul",tags:["Benchmarks","Voice AI","Data"],emoji:"📊",
   title:"Artificial Analysis Speech-to-Speech Index: GPT-Realtime-2 Leads, But at a Cost",
   summary:"A new composite quality score covers reasoning, conversational dynamics, and agentic tasks. GPT-Realtime-2 tops quality at 77.2% but TTFA jumps to 2.33s.",
   body:`Artificial Analysis launched a Speech to Speech Index — a single quality score averaging Big Bench Audio (reasoning), Full Duplex Bench (conversational dynamics), and τ-Voice (agentic tasks).

**How the models stack up (quality · TTFA · cost)**

- GPT-Realtime-2 (High) — 77.2% · 2.33s · $4.14
- Grok Voice Think Fast 1.0 — 75.7% · 1.25s · $3.00
- GPT-Realtime-1.5 — 72.0% · 0.82s
- Gemini 3.1 Flash Live (High) — 69.5% · 2.98s · $1.75

**How to read these numbers**

- Quality: equal-weighted average of Big Bench Audio (reasoning), Full Duplex Bench (conversational dynamics), and τ-Voice (agentic task completion).
- TTFA: Time To First Audio — how long after input the model starts producing audible speech.
- Cost: cost to run a fixed 40-question Big Bench Audio subset, normalized to cost per hour of input audio. Covers audio/text in+out and reasoning tokens; excludes caching discounts and tool-call costs. It's a comparison figure, not a real per-session price.

**For our 1.5 → 2 migration**

~+5pts quality (mostly in conversational dynamics), but TTFA jumps 0.82s → 2.33s. Worth checking against our latency budget before cutting over.`,
   link:"https://x.com/ArtificialAnlys/status/2069436163065282737"},
  {id:4,date:"2026-06-24",author:"Victor Zhinzherov",tags:["Anthropic","Slack","Enterprise"],emoji:"🔖",
   title:"Claude Tag: AI Becomes a Teammate Inside Slack",
   summary:"Anthropic introduced @Claude for Slack — tag it in any channel to delegate real work. Claude Tag is multiplayer: requests, reasoning, and corrections are visible to the whole team.",
   body:`Anthropic just introduced Claude Tag (@), a new way for teams to work with Claude directly inside Slack.

Instead of opening a separate chat, copying context, explaining the background again, and then bringing the result back to the team, you can tag @Claude inside a Slack channel and delegate work to it as part of the actual conversation.

**What is Claude Tag?**

Claude Tag lets Claude join selected Slack channels as a kind of AI teammate. Admins can decide which channels Claude can access, which tools or data sources it can use, and what permissions it should have.

For example:
- Claude could help summarize a long discussion
- Investigate a bug
- Analyze product metrics
- Follow up on unresolved threads
- Work through support tickets
- Help with engineering tasks when connected to the right tools and codebase

Claude can build context from the channels it is allowed to access, remember relevant information within that scope, and work more asynchronously on tasks instead of only answering one-off questions.

**Why this is different from a normal AI chat**

Most of us already use AI tools in a very personal workflow. We open Claude, ChatGPT, or Cursor, explain the context, ask for help, and then manually bring the output back to Slack, Linear, GitHub, or wherever the team works.

Claude Tag changes the direction: instead of moving the work to the AI tool, the AI joins the place where the work already happens. That makes it more "multiplayer" by default. Everyone in the channel can see the request, understand what Claude is doing, continue the conversation, correct it, add context, or use the result.

**Why this could be useful for engineering teams**

For developers, this can be very interesting because many of our daily workflows already start in Slack:
- A production issue is discussed in a channel
- A product question is raised in a thread
- Someone asks why a metric changed
- A deployment looks suspicious
- A teammate asks for a summary of what changed in a PR or incident

With Claude Tag, the workflow could become more natural: ask Claude to summarize a long technical thread, extract action items, investigate a bug using connected tools, or explain a code path.

**The enterprise angle**

Admins can control which tools, data, and channels Claude has access to. Claude's memory and context are scoped to the channels defined by administrators. Admins can also define token spend limits and view logs of what Claude did and who requested each task.

**Apartment List angle**

An IT request at Apartment List was already submitted for Claude Tag. Hopefully we will be able to try it soon inside our company Slack.

**The bigger picture**

Claude Tag feels like another step in the evolution from "AI as a tool I open" to "AI as a teammate I delegate to." Claude Code made AI more useful inside the development workflow. Cursor brought AI closer to the IDE. Now Claude Tag brings AI closer to team collaboration.`,
   link:"https://www.anthropic.com/news/introducing-claude-tag"},
  {id:5,date:"2026-06-24",author:"Tamir Tubul",tags:["Conference","React","Frontend"],emoji:"📍",
   title:"ReactNext 2026 Tel Aviv Recap: AI Is the Only Conversation in Frontend",
   summary:"Every session at ReactNext circled back to AI's impact on how we build. The 'Did AI kill frontend?' panel landed all over the map. Expertise still matters — AI amplifies it.",
   body:`Victor Zhinzherov, Itai Schvartzbard and I attended ReactNext yesterday. Quick rundown of what the frontend world is buzzing about.

**TL;DR**

Two big takeaways:
- We're not alone. The questions, debates, and tradeoffs the industry is chewing on are pretty much identical to the ones we wrestle with internally.
- AI is the conversation. Every single session, regardless of topic, circled back to AI's impact on how we build. There was literally a panel called "Did AI kill frontend?" and the panelists landed all over the map.

**What the sessions covered**

- AI & the shape of frontend: how AI lowers the barrier to entry, why model quality depends on the quality of code we feed it, and the rise of GEO (the subtler, AI-era cousin of SEO).
- Rethinking the stack: a genuinely interesting case for server-side rendering as a React alternative (templating + htmx), arguing that huge client bundles, made worse by AI, often aren't worth it.
- AI woven into the app itself: in-browser LLMs for error triage/recovery (window.languageModel), and autonomous testing agents now baked into Playwright (planner / generator / healer).
- Craft & performance: React's Activity component for perceived-performance wins, Figma MCP + Code Connect for design-to-code, React in the terminal via Ink.

**The "Did AI kill frontend?" panel**

The headline act. Most agreed: AI won't replace us, expertise still matters and AI amplifies it. A few highlights:

- Gil Tayar (Principal SWE @ Microsoft) still writes new features by hand to stay sharp, even when AI would be faster. He kept stressing that software development requires immense human expertise, to the point that he doesn't even buy into the term "Full Stack" — "you can't be an expert in both backend and frontend development." A bold take, but really well articulated.
- Shahar Polak's antidote to FOMO: consume learning in pull, not push. Kill the noise, dedicate 5 to 10 focused minutes a day to read and get inspired on your own terms.

**The motivating bit**

Yes, some of the AI talk pokes at frontend developers' long-term "relevance." But the throughline from the most experienced people in the room was empowering: AI lets you build more, with fewer dependencies, and turns expertise into a multiplier. The takeaway isn't "will I be replaced?" but "look how much more I can create."`,},
  {id:6,date:"2026-06-19",author:"Victor Zhinzherov",tags:["Security","JavaScript","pnpm"],emoji:"🔒",
   title:"pnpm: Why We Should Look Beyond npm and Yarn for Security",
   summary:"The strongest case for pnpm isn't speed — it's security. Stricter non-flat node_modules prevents phantom dependencies and supply-chain risk.",
   body:`At Apartment List, we already use JavaScript package managers every day. Depending on the project, that usually means npm, yarn, or yarn berry. So the natural question is: why should we look at another package manager like pnpm?

The answer is not that npm or Yarn are bad. But package management is no longer only about "how do I install dependencies?" The main reason this is important for us right now is security.

**What is pnpm?**

pnpm stands for "performant npm". It uses the same npm registry and the same package.json model we already know. The important difference is how pnpm stores and connects dependencies. Instead of copying the same package again and again into every project, pnpm stores packages in a shared content-addressable store and links them into each project.

pnpm uses a stricter node_modules layout that makes dependency access more explicit. In practice, this helps expose hidden dependency problems earlier.

**Why security is the main reason to care**

Key security advantages:
- Stricter dependency isolation
- Better protection against phantom dependencies
- More reproducible lockfile-based installs
- Better control over install/build scripts
- Ability to delay adoption of very new package versions
- Better visibility into dependency issues during install and CI

**The security edge: stricter dependency isolation**

One of pnpm's biggest security advantages is its strict, non-flat node_modules structure. In many npm or Yarn Classic setups, dependencies can be hoisted in a way that allows packages to access modules they did not explicitly declare. This creates phantom dependencies: code works only because some other dependency happened to bring the package into the tree.

From a security perspective, phantom dependencies make the dependency graph harder to audit.

**Phantom dependencies: a simple example**

Imagine a package imports chalk — but chalk is not listed in that package's package.json. With a flatter dependency structure, this may still work locally because another dependency brought chalk into node_modules. pnpm is stricter: if our code uses a package, that package should be declared directly.

**Build scripts and minimum release age**

Package lifecycle scripts, especially postinstall scripts, execute code during dependency installation. pnpm gives teams more control over this behavior — making script execution intentional and controlled.

Minimum release age: do not immediately install package versions that were published very recently. Compromised npm packages are often detected and removed quickly — sometimes within hours. A minimum release age policy adds a safety buffer.

**npm vs Yarn vs Yarn Berry vs pnpm**

- npm: stable, familiar, widely supported. Traditional dependency layout can be more permissive.
- Yarn Classic: improved developer experience over old npm. Still close to npm in node_modules behavior.
- Yarn Berry: Plug'n'Play model — no normal node_modules. Strict and efficient but may require extra migration work.
- pnpm: keeps a node_modules structure (tool-compatible), but uses symlinks, a shared store, and stricter isolation. The pragmatic middle path.

**The practical takeaway**

pnpm is not interesting because it gives us a new command to memorize. It is interesting because it improves the foundation of how JavaScript dependencies are managed. If we combine it with clear company standards, strict CI, lockfile discipline, and vulnerability scanning, it can help make our JavaScript projects safer, cleaner, faster, and easier to maintain.`,
   link:"https://pnpm.io/supply-chain-security"},
  {id:7,date:"2026-06-19",author:"Victor Zhinzherov",tags:["Anthropic","Claude Code","Research"],emoji:"🧠",
   title:"AI Will Not Replace Professionals. It Will Amplify Them",
   summary:"Anthropic's study of 400K Claude Code sessions: expert users get 5x more output and 12 actions per prompt vs 5 for beginners — same model, radically different results.",
   body:`Anthropic recently published a very interesting research report about how people actually use Claude Code in real coding workflows.

The research is based on a privacy-preserving analysis of around 400,000 Claude Code sessions from about 235,000 users between October 2025 and April 2026.

The main takeaway is simple but important: AI does not remove the need for expertise. It actually makes expertise more valuable.

**What Anthropic Found**

One of the strongest findings is the difference between beginners and experts.

Less experienced users usually give simpler prompts, which lead Claude Code into shorter chains of work. Those sessions average around 5 actions per prompt.

More experienced users behave differently. They usually define the problem better, give stronger context, explain constraints, and know what kind of result they want. In expert sessions, Claude performs around 12 actions per prompt and produces about 5x more output.

The model is the same, but the quality of the human direction changes the outcome completely.

**The New Skill: Steering the Agent**

The research shows a clear division of labor. Humans are still making most of the planning decisions: what should be built, what the goal is, which direction makes sense, and what success should look like. Claude Code is taking more of the execution work: reading files, editing code, running commands, checking errors.

The value is no longer only in manually writing every line of code. More and more, the value is in knowing how to define the work, guide the agent, review the result, and correct the direction when needed.

**Why Expertise Matters Even More**

AI can generate code for almost anyone, but that does not mean the result is correct, safe, maintainable, or aligned with the real business need. Without expertise, it is very easy to accept a solution that looks good but creates hidden problems.

A strong engineer knows what to ask for, which files matter, what constraints should be mentioned, what edge cases must be tested, and when the agent is going in the wrong direction.

That is why AI becomes much more powerful in the hands of someone who already understands the domain. The better you understand the system, the deeper the agent can run.

**The Real Takeaway**

The future is probably not "AI replaces professionals."

A better way to think about it: Professionals who know how to work with AI will outperform professionals who do not.

Claude Code is not a magic replacement for engineering judgment. It is a force multiplier for people who know how to use it well. The real superpower is not just prompting — it is combining domain knowledge, technical judgment, good context, clear constraints, and strong review habits into an AI-native workflow.`,
   link:"https://www.anthropic.com/research/claude-code-expertise"},
  {id:8,date:"2026-06-18",author:"Victor Zhinzherov",tags:["Cursor","SpaceX","AI War"],emoji:"🚀",
   title:"SpaceX Buying Cursor for $60B Is About the AI Platform War",
   summary:"This isn't about an IDE — it's about owning the developer workflow. OpenAI has Codex, Anthropic has Claude Code. Grok needs a daily-use product to compete.",
   body:`SpaceX is reportedly acquiring Cursor, the AI coding startup behind one of the most popular AI-powered development environments, in a deal valued at around $60 billion.

The more interesting part is not only that SpaceX wants an AI coding tool. The more interesting part is that this looks like a strategic move in the AI platform war. OpenAI already has ChatGPT, Codex, strong developer APIs, and deep adoption. Anthropic has Claude and Claude Code. Grok has visibility and Elon Musk's ecosystem behind it, but still needs stronger adoption inside real developer workflows. That is where Cursor becomes very interesting.

**Cursor is not just an IDE**

Cursor owns a very important layer: the developer workflow. It is not only a place where developers ask AI to write code. It is where they open their repository, read files, understand architecture, ask questions, generate changes, review diffs, write tests, and move from idea to implementation.

The next phase of AI competition is not only about which company has the best chatbot or the smartest model. It is about which company owns the workflow where AI becomes useful every day.

**Why this helps SpaceX and Grok fight back**

If SpaceX and xAI want Grok to compete seriously with OpenAI and Anthropic, they need more than a strong model. They need distribution, daily usage, product trust, and real workflows where people depend on Grok as part of their work.

Cursor gives them a shortcut into one of the most valuable AI markets: software development. Instead of trying to convince developers to switch to Grok only through a chatbot interface, SpaceX can push Grok through a tool developers already understand.

**The $60B number tells us something**

A $60 billion acquisition shows how valuable AI coding has become. The market is no longer treating AI coding tools as small developer utilities. It is treating them as strategic platforms.

If AI coding agents become one of the main interfaces between developers and codebases, then the company that controls that interface controls a very important layer of the software economy.

**The bigger picture**

The Cursor acquisition is not just about SpaceX wanting better coding tools. It is about owning a strategic layer in the AI stack. Models are important, but models alone are not enough. The winning companies also need products, workflows, distribution, trust, and daily usage.

For developers, the important part is this: The future of AI coding will not be only about who has the smartest model. It will also be about who owns the workflow where developers actually use AI every day.`,},
  {id:9,date:"2026-06-13",author:"Victor Zhinzherov",tags:["Anthropic","Policy","Security"],emoji:"⚖️",
   title:"When AI Model Releases Become a National Security Question",
   summary:"Anthropic suspended Fable 5 and Mythos 5 following a US government export control directive targeting foreign nationals. The bigger question: who decides when a model is too risky?",
   body:`Anthropic published a very unusual statement: following a US government export control directive, it is suspending access to Fable 5 and Mythos 5.

The important detail is that the directive is specifically about foreign nationals. According to Anthropic, the US government ordered the company to suspend access to these models by any foreign national, whether they are inside or outside the United States, including foreign national Anthropic employees.

Because Anthropic cannot easily guarantee this across all access paths, the practical result is that they are disabling Fable 5 and Mythos 5 for all customers for now. The reason given by the government is national security — the directive appears to be connected to a potential jailbreak technique that may allow the model to bypass some safeguards in cybersecurity-related scenarios.

**The technical issue: jailbreaks are still unsolved**

Anthropic's position is that Fable 5 had strong safeguards and was red-teamed heavily before launch. They also claim that no universal jailbreak was found.

That distinction matters:
- A universal jailbreak means a broad technique that can consistently bypass safeguards.
- A narrow jailbreak is more limited — it may work only in specific contexts, specific prompts, or specific task types.

Anthropic argues that the reported issue belongs to the second category, and that if every narrow jailbreak becomes enough reason to recall a model, frontier model deployment could become almost impossible.

**Why this matters for developers**

For developers, this story is a reminder that AI security is becoming part of normal software engineering. The same capabilities that help defenders find and fix vulnerabilities can also help attackers understand where to look. This dual-use nature is what makes cybersecurity one of the most complicated areas for AI.

**The bigger question: who decides?**

Who decides when a model is too risky to release? Should it be the model provider? The government? An independent technical process? Should decisions be based on private evidence, public benchmarks, or external audits?

Anthropic says it supports the idea that governments should be able to block unsafe deployments, but argues that this should happen through a transparent and technically grounded process.

**My take**

The conversation is moving from "Which model is smarter?" to "Which model is safe enough to deploy, who is allowed to use it, and under what conditions?"

The most powerful AI systems will not be adopted only based on capability. They will be adopted based on trust, control, monitoring, and the ability to prove they are being used safely.`,},
  {id:10,date:"2026-06-10",author:"Victor Zhinzherov",tags:["Anthropic","Claude","Model Release"],emoji:"🔬",
   title:"Claude Fable 5: A New Model, and a New Way to Release Frontier AI",
   summary:"Fable 5 is Anthropic's strongest public model. But the more important story is the release architecture: Fable 5 (public) vs Mythos 5 (trusted-access). The system around the model matters as much as the model.",
   body:`Anthropic released Claude Fable 5, and this release is interesting for more than the usual "new model is better" story.

Yes, Fable 5 is more capable. Anthropic describes it as their strongest generally available model so far, with major improvements in software engineering, knowledge work, vision, scientific research, and long-running tasks.

But the more important part is how Anthropic is choosing to expose these capabilities. This is not just a model launch. It is also a good example of where frontier AI products are heading: more powerful models, more autonomous behavior, and much stronger controls around who can use which capability and in what context.

**What did Anthropic release?**

- Claude Fable 5 is the public version. It is a Mythos-class model that Anthropic says was made safe enough for general use. Some sensitive requests will be handled by Claude Opus 4.8 instead.
- Claude Mythos 5 is the same underlying model, but with some safeguards lifted for a limited group of trusted users — mainly cyberdefenders, infrastructure providers, and later selected biology researchers.

That split is important. We are moving toward a world where access to AI capabilities depends on the user, the use case, the risk level, and the safety layer around the model.

**Why this release matters for developers**

For developers, the most interesting part of Claude Fable 5 is its focus on long-horizon software engineering.

We are used to thinking about AI coding tools as helpers for local tasks: write a function, explain a bug, generate tests, refactor a file. But the real shift is toward models that can work through larger engineering problems for longer periods of time.

Examples:
- Migrating code across a large codebase
- Understanding unfamiliar services
- Making changes across multiple files
- Debugging failures after running tests
- Rebuilding UI from screenshots
- Using memory and notes across a long task

**The model is stronger, but the system around it matters more**

When Fable 5 detects certain sensitive requests, the response may be handled by Claude Opus 4.8 instead. This applies to areas like cybersecurity, biology and chemistry, and distillation attempts.

Instead of simply refusing everything risky, Anthropic is trying to route some requests to a less capable but still useful model. This is a good reminder for anyone building AI products: the model itself is only one part of the system.

The full product also includes:
- Classifiers, routing logic, access control
- Logging, permissions, data retention policies
- Human review flows, safety boundaries, fallback behavior

**My take**

Claude Fable 5 is an important release because it shows both sides of the current AI story. On one side, models are becoming much more capable. On the other side, those same capabilities are becoming harder to release without strong controls.

The question is no longer only "Which model should I use?" The better question is "What should this model be allowed to see, what should it be allowed to do, and where do I need human approval?"`,
   link:"https://www.anthropic.com/news/claude-fable-5"},
  {id:11,date:"2026-06-01",author:"Victor Zhinzherov",tags:["Anthropic","Claude Code","Setup"],emoji:"⚡",
   title:"Moving Claude Code to Claude Enterprise — Step-by-Step",
   summary:"Apartment List now provides every full-time employee a Claude Enterprise seat. Here's how to migrate Claude Code from Console API auth to Enterprise SSO in 3 steps.",
   body:`Hey team, Apartment List now provides every full-time employee with a Claude Enterprise seat. This means we now have access to both Claude Chat through claude.ai and Claude Code through our Enterprise account.

Until now, we used the Claude Console API flow to work with Claude Code and authenticate. Going forward, we should move Claude Code to use our new Claude Enterprise account instead.

**How to switch Claude Code to Claude Enterprise**

1. Open Claude Code.
2. Run: /logout (This will log you out from your current Claude Console account.)
3. Open Claude Code again.
4. When you reach the authentication step, choose option 1 → "Claude account with subscription"
5. Authenticate using your work email (SSO)

That's it. Claude Code should now be connected to your Claude Enterprise seat.

**Important things to know**

- Your Claude Code session history should remain available after logging out. Access previous sessions by running: /resume
- Your installed MCP servers should remain configured. You do not need to reinstall them, but you may need to re-authenticate them.

**How to re-authenticate MCPs**

1. Open Claude Code
2. Run: /mcp
3. Look for any MCP that shows: △ needs authentication
4. Click each one and complete the authentication flow again.

**Small reminder**

Even though Claude Enterprise gives us higher usage limits, usage still has real cost behind it. Try to use clear prompts, provide good context, and avoid long chains of tiny follow-up requests when one better prompt can do the job.

Also, the same company rules apply:
- Do not paste PII or sensitive information.
- Treat Claude outputs as drafts, not final truth.
- Review everything before using it in code, docs, tickets, or Slack.
- Use the Enterprise seat for Apartment List work only.`,},
  {id:12,date:"2026-05-28",author:"Victor Zhinzherov",tags:["Anthropic","Claude","Honesty"],emoji:"🎯",
   title:"Claude Opus 4.8: Not Just Smarter AI, But More Honest AI",
   summary:"The headline improvement in Opus 4.8 is honesty — 4x less likely to let code flaws pass without flagging them. Confident-but-wrong is more dangerous than uncertain-and-correct.",
   body:`Anthropic released Claude Opus 4.8. The part I find most interesting is not only that the model became stronger. The more important part is that Anthropic is clearly focusing on something that matters a lot in real engineering work: honesty.

For developers, this is a big deal because the biggest risk with AI tools is not always that they make mistakes. The bigger risk is when they make mistakes confidently, continue building on top of those mistakes, and make us believe we are making progress when the foundation is actually weak.

**Why Honesty Matters More Than It Sounds**

One of the most prominent improvements Anthropic highlights in Opus 4.8 is honesty. The model is more likely to flag uncertainty about its own work and less likely to make claims it cannot support.

Even more interesting: Anthropic says Opus 4.8 is around four times less likely than Opus 4.7 to allow flaws in code it has written to pass without mentioning them.

A model that tells you "this assumption may be wrong," "this part needs verification," or "there may be a flaw in the code I just wrote" is often more useful than a model that confidently gives you a clean-looking solution with hidden problems. In real codebases, confidence without correctness is expensive.

**Why This Matters for Coding Agents**

Opus 4.8 is better at coding tasks, agentic workflows, long-running work, tool usage, and following style direction.

We are increasingly asking AI coding tools to read existing code, understand architecture, make changes across multiple files, run tests, debug failures, explain tradeoffs, and follow team conventions. At that point, raw intelligence is not enough. The model also needs judgment — to know when to slow down, when to verify, and when to tell the developer that something is uncertain.

**Dynamic Workflows: Bigger Tasks, Bigger Responsibility**

Another interesting part of the release is the new "dynamic workflows" feature for Claude Code, currently in research preview. Anthropic describes it as a way for Claude Code to take on much larger tasks by planning the work, running many parallel subagents in a single session, and verifying outputs before reporting back to the user.

A wrong assumption multiplied across many files, many subagents, and a large migration is a much bigger problem than a wrong assumption in one function. As AI agents become more capable, the need for self-checking becomes more important, not less.

**Effort Control: Choosing Between Speed and Depth**

Another practical update is effort control in Claude.ai and Cowork. This lets users choose how much effort Claude puts into a response — lower effort for quick explanations, higher effort for deeper reasoning and production decisions. Not every task needs the same level of reasoning.

**The Enterprise Angle**

For engineering teams, the most important questions become:
- Can we trust its judgment?
- Does it expose uncertainty?
- Does it catch its own mistakes?
- Does it follow our architecture?
- Does it reduce review time or increase it?
- Can it work safely across a real codebase?

The best AI coding tool is the one that helps engineers move faster while keeping quality, safety, and maintainability under control.`,
   link:"https://www.anthropic.com/news/claude-opus-4-8"},
  {id:13,date:"2026-05-28",author:"Victor Zhinzherov",tags:["AI Agents","Technical Debt","Context"],emoji:"🧹",
   title:"When AI Agent Skills Become Technical Debt",
   summary:"Peter Steinberger (OpenClaw creator) released skill-cleaner, a tool that audits CLAUDE.md rules for duplicates and context bloat. The bigger point: AI agent context is now infrastructure.",
   body:`Recently, Peter Steinberger released skill-cleaner, a small but interesting tool for auditing AI agent skills. The idea behind it is much bigger than the tool itself — it points to a new type of engineering problem we are starting to see more often: AI context is becoming infrastructure.

As developers, we are giving AI coding agents more and more instructions in forms like CLAUDE.md, AGENTS.md, custom rules, reusable prompts, project-specific workflows, and agent skills for specific tasks.

All of this is useful — but there is also a hidden cost. Every instruction, skill description, duplicated rule, and outdated workflow can become part of the context the agent needs to process.

**Why Peter Steinberger's Perspective Matters**

Peter is the founder of PSPDFKit and the creator of OpenClaw, an open-source AI agent project that became highly visible in the AI developer community. His perspective is based on real hands-on work with AI agents, not only theory.

**The Hidden Cost of Too Much Context**

skill-cleaner audits AI agent skills and looks for things like duplicate skills, unused skills, long descriptions, loaded skill roots, and prompt-budget pressure.

The dangerous part is that this type of problem is not always visible. When a regular service becomes slow, we can look at logs, metrics, traces, memory usage, or database queries. But when an AI agent starts behaving worse because the context around it became messy, the signal is much harder to detect. It may just feel like the agent is less focused, more expensive, or making strange decisions.

**AI Agent Context Can Also Create Technical Debt**

At the beginning, adding more instructions feels harmless. Each addition may make sense on its own: one more helper script, one more shared rule, one more workflow. But over time, if nobody cleans it up, the system becomes harder to reason about. This is very similar to regular technical debt.

**From AI Experimentation to AI Engineering Discipline**

AI-assisted development is moving from experimentation into engineering discipline. The first phase was mostly about excitement. The next phase is about making these tools reliable, efficient, safe, maintainable, and aligned with real engineering workflows.

**Better Models Still Need Better Context**

A good AI agent setup needs focused instructions, clear skills, minimal duplication, up-to-date workflows, removed stale experiments, and ownership over shared rules and prompts.

A powerful model with messy context can still produce messy results. The future of AI-assisted development is not only about better models. It is also about better context hygiene.`,
   link:"https://github.com/steipete/agent-scripts/tree/main/skills/skill-cleaner"},
  {id:14,date:"2026-05-27",author:"Victor Zhinzherov",tags:["Security","AI Agents","Prompt Injection"],emoji:"🛡️",
   title:"AI Coding Agents Are Powerful. That Means We Need Better Guardrails",
   summary:"Prompt injection is real: malicious instructions can hide in README files, code comments, test data, and logs. Four protection layers for your AI coding workflow.",
   body:`We are no longer using AI only as autocomplete. Tools like Claude Code, Cursor, ChatGPT, and other coding agents can read files, understand repositories, suggest changes, run terminal commands, modify code, inspect logs, and sometimes connect to external tools.

So the security question is no longer only: "Can AI generate insecure code?" The bigger question is: "What happens when the AI itself is tricked into doing something unsafe?"

**The Core Risk: Prompt Injection Inside Developer Workflows**

In a regular workflow, we give the AI an instruction like: "help me debug this issue." But while doing that, the AI may read other text from different sources — README files, source code comments, test data, logs, package metadata, generated files, PDFs, local JSON files, GitHub issues, pull requests.

A malicious instruction can be hidden inside content that looks completely normal to us. A human may ignore it as a comment or test value, but the AI may interpret it as an instruction.

**A More Realistic Example: Using a Public Repo**

Imagine we are working on a new feature and find a public GitHub repository that solves a similar problem. We ask the AI coding agent to inspect that repo through an MCP server or GitHub integration.

At this point, the AI may read the repository remotely — README, source files, package scripts, examples, test files, comments, configuration files, issues, and pull requests. If the repository is malicious, a comment inside a test file or a hidden note in the README could tell the AI to inspect our local environment, read sensitive files, call another tool, or run a command.

The important point: we did not ask the AI to read secrets. We only asked it to help us understand a public repo. But because the AI may have access to multiple tools at the same time, the malicious text from the public repo may try to influence the agent into using permissions from another context.

Public repositories, code samples, templates, copied snippets, and demo projects should be treated as untrusted input when used with AI agents.

**Where Malicious Instructions Can Hide**

- README files, source code comments, test files
- Log files (user-generated content written to logs)
- Local data files (JSON, SQLite, CSV, PDFs)
- Generated documentation, HTML templates, package files
- Commit messages, GitHub issues, pull requests
- External tool responses, MCP tool output

**Protection Layer 1: Work in the Smallest Possible Scope**

Give the AI only the context it actually needs. If we need help with one module, we do not always need to open the entire repository.

**Protection Layer 2: Block Access to Sensitive Files**

Explicitly block the AI from reading sensitive paths — .env, .env.local, secrets.json, credential folders, private keys. A real security boundary should prevent access even if the AI is manipulated.

**Protection Layer 3: Be Careful With Terminal Commands**

Commands that delete files, print sensitive file content, change permissions, install dependencies, modify shell configuration, or send data over the network should always get extra attention.

Approval fatigue is dangerous. After enough prompts, it becomes easy to approve whatever the AI asks to run. Ask: does this command make sense for the task I requested?

**Protection Layer 4: Add Project-Level AI Rules**

A project-level instruction file like CLAUDE.md can define rules: do not read secrets, do not print credentials, do not add API keys directly into code, explain risky terminal commands before suggesting them.

This is not about being afraid of AI. It is about treating AI coding agents like any other powerful development tool. We would not run a random shell script from the internet without checking it. AI agents deserve the same engineering discipline.`,},
  {id:15,date:"2026-05-26",author:"Victor Zhinzherov",tags:["Enterprise","AI Adoption","Economics"],emoji:"🏢",
   title:"When AI Coding Tools Meet Enterprise Reality",
   summary:"Microsoft reportedly dropped Claude Code after burning its yearly AI budget in months. Uber had the same issue. Enterprise AI adoption is more complicated than it looks.",
   body:`Recently there have been reports that Microsoft is planning to drop Claude Code by June 30 after burning through its yearly AI budget in just a few months.

The important part here is not only the Microsoft story itself. The bigger point is what it tells us about the current state of AI adoption inside large companies.

We keep hearing "AI is going to replace programmers" — but real-world enterprise adoption shows a much more complicated picture. AI coding tools are powerful, useful, and already changing how engineers work, but adopting them at scale is not as simple as giving everyone access and expecting unlimited productivity gains.

**AI coding tools are useful, but usage at scale is expensive**

For an individual engineer, tools like Claude Code, Cursor, GitHub Copilot, and other AI coding assistants can feel extremely valuable. The challenge starts when this usage moves from a single developer to thousands of engineers. At that point, every prompt, every file read, every codebase analysis, and every generated response has a cost behind it.

**This is not only a Microsoft problem**

Uber reportedly faced a similar situation, where its AI coding tool usage grew so quickly that the company burned through its AI budget much earlier than expected.

The issue is a broader enterprise challenge. Large companies are still learning how to adopt AI coding tools in a way that is useful, measurable, and financially sustainable.

**The "AI will replace programmers" narrative is too simple**

A big part of engineering is understanding business logic, production behavior, system design, edge cases, architecture, observability, security, and long-term maintainability. AI can help with many of these areas, but it does not remove the need for engineering judgment.

Actually, the more AI-generated code we introduce, the more important engineering judgment becomes. Someone still needs to decide whether the output is correct, whether the design makes sense, whether the change is safe, and whether the code will be maintainable six months from now.

**My takeaway**

AI coding tools are not magic, but they are also not hype. They are becoming a real part of the engineering workflow, but enterprise adoption is proving that the value is not automatic.

The companies that benefit the most will probably not be the ones that simply buy the most AI licenses. They will be the ones that learn how to combine AI tools with strong engineering practices, clear ownership, thoughtful architecture, and good cost control.`,},
  {id:16,date:"2026-05-24",author:"Victor Zhinzherov",tags:["Security","VS Code","Supply Chain"],emoji:"🔐",
   title:"GitHub Breach: How a Poisoned VS Code Extension Exposed 3,800 Repos",
   summary:"A compromised version of Nx Console (18.95.0) was live for 18 minutes in VS Marketplace. It harvested GitHub tokens, AWS credentials, SSH keys, and more. Developer tooling IS the security surface.",
   body:`Today's tech talk is about a recent GitHub security incident. The main takeaway: The tools we install locally are part of our security surface.

On May 18, 2026, GitHub discovered and contained an attack that started from one of its employee's development machines. The attacker started through a poisoned VS Code extension — Nx Console version 18.95.0, a compromised version of a popular VS Code extension. The malicious version was available for around 18 minutes in the Visual Studio Marketplace and around 36 minutes in OpenVSX before it was removed.

**What happened**

A GitHub employee had the compromised Nx Console 18.95.0 extension installed. Since VS Code extensions run inside the developer's local environment, the malicious code was running close to sensitive developer context: source code, local files, authenticated CLI tools, GitHub access, tokens, SSH keys, cloud credentials.

From that compromised employee machine, the attacker was able to access and exfiltrate GitHub-owned internal repositories. GitHub said the attacker claimed access to around 3,800 repositories.

**Why this is serious**

The Nx Console advisory shows how dangerous this type of compromise can be. The malicious extension attempted to harvest credentials from multiple sources, including:
- GitHub tokens, NPM tokens
- AWS credentials, Vault tokens, Kubernetes-related credentials
- Private keys, GCP and Docker credentials
- Connection strings, 1Password CLI data (if an active session existed)

Harvested data was exfiltrated through HTTPS, the GitHub API, and DNS.

**Why this matters for us**

VS Code and Cursor are not only editors. With extensions, they become platforms that can interact with our workspace, read files, execute commands, inspect environment variables, integrate with Git, and run near tools that may already be authenticated.

Installing an extension on a work machine is not only a productivity decision. It is also a trust decision.

**Good habits before installing extensions**

Before installing a new extension, especially on a work machine, check:
- Is this extension from a trusted publisher?
- Is the extension widely used and actively maintained?
- Is the name exactly correct, or could it be a fake or typo-squatted extension?
- Does it have a real repository, documentation, and update history?
- Does it request broad access to the workspace, terminal, Git, or credentials?
- Are there any recent security advisories related to it?

It is also worth periodically removing extensions we no longer use.

**Takeaway**

Developer tools make us faster, but they also run very close to sensitive systems. Before installing a VS Code/Cursor extension or any other local development tool, treat it like adding a new dependency to your work environment.

If we would not trust the tool with our source code, tokens, and local environment, we should NOT install it on a work machine. Small habit, big impact.`,
   link:"https://github.blog/security/investigating-unauthorized-access-to-githubs-internal-repositories/"},
  {id:17,date:"2026-05-20",author:"Victor Zhinzherov",tags:["Anthropic","Karpathy","AI Research"],emoji:"🤖",
   title:"Andrej Karpathy Joins Anthropic",
   summary:"Karpathy (OpenAI founding member, Tesla AI lead, vibe-coding popularizer) is joining Anthropic's pretraining team. For developers, this connects directly to how CLAUDE.md shapes our workflow.",
   body:`Another interesting move in the AI world: Andrej Karpathy is joining Anthropic.

Karpathy announced that he is joining Anthropic and returning to R&D, saying that the next few years at the frontier of LLMs will be especially formative.

This is a notable move because Karpathy is one of the most recognized names in AI, with a background that includes being a founding member of OpenAI, leading AI work at Tesla, returning to OpenAI in 2023, and later founding Eureka Labs, an AI-native education startup.

**Why developers should care**

We already know Karpathy's work from the "Skills for AI Coding Agents" ideas that inspired part of our day-to-day CLAUDE.md rules.

Karpathy has been one of the clearest voices explaining that coding is changing from writing every line manually into a workflow where developers guide, review, correct, and orchestrate AI agents. He also popularized the term "vibe coding," which describes a style of development where the developer works mostly through natural language, iterates with the model, and lets the AI produce much of the code.

The important point is not that developers stop understanding code. The important point is that the developer role is moving higher up the stack. Instead of only asking "How do I implement this function?", we increasingly ask "How do I design the right system, give the agent the right context, validate the result, and make sure the generated code is safe, maintainable, and production-ready?"

**Why Anthropic is an interesting place for him**

Karpathy is joining Anthropic's pretraining team, which is responsible for the foundational training behind Claude models. He is also expected to help with work focused on using Claude to improve pretraining research itself.

That last part is especially interesting: Using AI to improve AI research. It means models are not only products that developers use, but also tools that researchers use to make the next generation of models better.

**The bigger picture**

For developers, the tools we use over the next few years will likely be shaped by this kind of research:
- Stronger coding agents
- Better long-context reasoning
- More reliable tool usage
- Improved autonomous debugging
- Better model-generated tests
- Safer agent workflows
- AI systems that can help with large codebases, not only small snippets

The real takeaway: AI coding agents are getting better, and people like Karpathy are now working directly on the next generation of these systems. For us as developers, the best move is not to ignore this shift, but to learn how to use these tools professionally and responsibly.`,},
  {id:18,date:"2026-03-17",author:"Victor Zhinzherov",tags:["Claude Code","MCP","Setup Guide"],emoji:"📚",
   title:"Claude Code MCP Installation Guide — GitHub, Slack, Figma, Jira, BigQuery & More",
   summary:"Tamir Tubul put together a comprehensive MCP Installation Guide covering 10+ integrations. File available via 1Password.",
   body:`I'm excited to share the AI Nurture team's Claude Code MCP Installation Guide!

This guide includes the MCPs we use most often in day-to-day work:
- GitHub, Slack, DataDog, Jira (Atlassian), Figma, Notion, Google Drive, Jenkins
- BigQuery (AList Prod, AI Lea Prod)
- MongoDB (Alist Stage, Alist Prod, AI Lea Stage, AI Lea Prod)

This is a very powerful set of MCPs that covers just about everything we need in our daily workflow. The document explains in detail how to install each MCP server in Claude Code and how to use it.

**Each MCP is installed with the appropriate scope**

- User scope — installs the MCP so it's available across all your local projects
- Local scope — installs the MCP only for the specific repo you're currently working in. For example, Mongo MCP would typically be installed locally since it's usually tied to a specific project rather than all repos.

We strongly encourage everyone to try these MCPs along with Claude Code. The day-to-day workflow improvement is huge, and the experience of using MCPs in Claude Code is significantly better than using them in Cursor. Claude Code is simply on another level here.

You can download the Claude MCP Installation Guide file from 1Password (link in the original Slack post).

A huge thank you to Tamir Tubul for putting this together for the team.`,},
  {id:19,date:"2026-03-05",author:"Victor Zhinzherov",tags:["OpenAI","GPT-5.4","Model Release"],emoji:"✨",
   title:"GPT-5.4 Thinking: What Actually Changed Across ChatGPT, API, and Codex",
   summary:"GPT-5.4 is a three-surface rollout: ChatGPT gets a Thinking tier refresh, the API gains native computer-use and tool search, Codex gets 1M token context.",
   body:`Today (March 5, 2026), OpenAI released GPT-5.4 — a platform rollout across three different surfaces:
- ChatGPT (new GPT-5.4 Thinking experience and a higher-end GPT-5.4 Pro option)
- API (new gpt-5.4 / gpt-5.4-pro models for building products and agent workflows)
- Codex (GPT-5.4 integrated into coding workflows with experimental long-context support)

The theme of the release is making GPT-5 better at bigger, more complex tasks: agents that can actually execute steps (including "computer use"), more reliable tool-heavy workflows, and higher-quality "deliverables" like docs, spreadsheets, and presentations.

**What Changed in ChatGPT**

- GPT-5.3 Instant stays the default for everyday chat (fast, lightweight)
- GPT-5.4 Thinking is the option you pick for bigger, multi-step tasks
- GPT-5.4 Thinking replaces GPT-5.2 Thinking (moving to Legacy for 3 months, retires June 5, 2026)
- GPT-5.4 Pro appears for Pro + Enterprise users as the "max performance" variant

**What Changed in the API**

- New API models: gpt-5.4 and gpt-5.4-pro
- Native "computer use": can issue mouse + keyboard actions based on screenshots, write automation code (Playwright-style workflows)
- Tool search: instead of stuffing every tool schema into context, the model can "find the right tool"
- Up to 1M tokens context (for API + Codex)
- GPT-5.4 is claimed to be OpenAI's most token-efficient reasoning model yet

**What Changed in Codex**

- GPT-5.4 is now the "mainline" reasoning model in Codex
- First mainline reasoning model that incorporates the frontier coding capabilities of GPT-5.3-Codex
- Experimental 1M context support (requests beyond standard window count at 2x the normal rate)

**GPT-5.4 is also available in Cursor**

You can select it in the model dropdown, use it for repo-level chat, and use it for refactors, debugging, and completions inside the editor.

**Bottom Line**

GPT-5.4 is basically: better completion of real workflows, not just better answers. Key upgrades: agent execution (computer use + browsing + tools), longer horizons (up to 1M context in API/Codex), better deliverables (docs/sheets/slides), and cleaner separation by surface.`,
   link:"https://openai.com/index/introducing-gpt-5-4/"},
  {id:20,date:"2026-02-27",author:"Victor Zhinzherov",tags:["Google","Image Generation","Gemini"],emoji:"🎨",
   title:"Nano Banana 2 Is Here: Google's Fast Image Generation Gets Serious",
   summary:"Nano Banana 2 improves prompt understanding, iteration consistency, and multimodal context. The question has shifted from 'can AI generate images?' to 'can AI reliably integrate image generation into real systems?'",
   body:`On February 26, Google officially released Nano Banana 2, the next evolution of its lightweight but powerful AI image generation model.

**What Is Nano Banana 2?**

Nano Banana 2 is Google's latest fast image generation model, designed to balance speed (low latency), high-quality outputs, iterative image refinement, and strong multimodal understanding.

It powers image generation inside the Gemini ecosystem, including the Gemini app and developer APIs.

**What's New in Nano Banana 2?**

1. Better Prompt Understanding — The model interprets more complex, layered prompts more accurately, including style, lighting, camera angle, composition, and fine-grained visual instructions.

2. Stronger Consistency Across Iterations — You can refine an image step-by-step while maintaining character consistency and scene coherence. This is huge for workflows where you progressively tweak an image.

3. Improved Multimodal Context — It handles image + text inputs better, meaning you can modify an existing image with text instructions, combine visual context with structured guidance, and maintain alignment between description and output.

4. Developer-Ready Integration — Nano Banana 2 is available via Gemini APIs, making it easier to build image-based features into apps, create rapid visual prototypes, and automate creative workflows.

**Why This Matters for Developers**

This release isn't just about prettier pictures. It signals:
- Lightweight models are getting seriously capable
- Faster inference without major quality tradeoffs
- Iterative generation is becoming a first-class workflow
- Multimodal models are stabilizing for production use

**Bigger Picture**

We're seeing a shift from "Can AI generate an image?" to "Can AI reliably generate, refine, and integrate images into real systems?" Nano Banana 2 is part of that shift. Fast models are no longer "lite" versions. They're becoming powerful, stable, developer-friendly, and multimodal by default.`,
   link:"https://gemini.google/overview/image-generation/"},
  {id:21,date:"2026-02-25",author:"Victor Zhinzherov",tags:["Anthropic","Claude Code","Remote"],emoji:"📱",
   title:"Claude Code Just Got Remote Control",
   summary:"Start a Claude Code session locally, generate a QR code, and continue from your phone or another browser. Your local machine stays the execution environment.",
   body:`Imagine you're deep into a complex Claude Code project, everything's running on your machine — and suddenly you need to head out. Instead of stopping everything, you pull out your phone and continue right from where you left off. No cloud, no copying files, no complicated setup.

On February 24, 2026, Anthropic launched a new Remote Control feature for Claude Code that makes this scenario a reality.

**What Remote Control Actually Does**

Remote Control lets you:
- Start Claude Code locally on your machine
- Generate a secure session link (or QR code)
- Connect to that exact running session from another device

You are not running Claude in the cloud. Your local machine stays the execution environment.

That means: access to your local filesystem, access to your installed tools, access to MCP servers, and the same project context and terminal state.

**How To Use It**

From your terminal: claude remote-control
Or inside an active Claude session: /remote-control

Claude will generate a secure session URL, a QR code, and connection logs when a remote device joins. Open the link from your browser or Claude mobile app, and you'll see the same session in real time.

**Security Model**

Remote Control does not open inbound ports on your machine. It works over outbound HTTPS connections, similar to how Claude normally communicates with Anthropic's API. The session is encrypted and tied to your authenticated account.

**Availability**

Remote Control is currently available as a research preview feature and is accessible on specific Claude Code subscription tiers such as Pro and Max.

**Why This Is Interesting**

Until now, Claude Code was tied to the physical machine where you launched it. Remote Control turns it into something closer to a persistent AI coding session that you can monitor while a long task is running, continue from your phone, answer clarifying questions remotely, and guide refactors without sitting at your desk. It keeps the power of local development but removes the device constraint.`,
   link:"https://code.claude.com/docs/en/remote-control"},
  {id:22,date:"2026-02-25",author:"Victor Zhinzherov",tags:["Figma","Claude Code","Design-to-Code"],emoji:"🖼️",
   title:"Claude Code to Figma: Turn Live UI Into Editable Design Frames",
   summary:"Figma released a workflow that captures live browser UI and converts it to fully editable Figma frames via MCP. Type 'Send this to Figma' in Claude Code to trigger.",
   body:`On February 17, Figma released Claude Code to Figma — a feature that lets you capture a live, running UI from your browser and convert it into fully editable Figma design frames.

This isn't just exporting screenshots or generating mockups. It turns actual UI you're working with — whether on localhost, staging, or production — into real layers, components, and layout structures on the Figma canvas.

**What Is Claude Code to Figma?**

Claude Code to Figma allows developers to:
- Capture live rendered UI from a browser
- Translate that UI's structure, layout, text, and components
- Generate an editable Figma frame that designers can refine, annotate, or share

Unlike flat screenshots, the output maintains structural information so the UI feels like an actual design asset, not a static image.

**How Do You Set It Up?**

1. Install the Figma MCP server — This enables Claude Code to communicate with Figma.
2. Connect Claude Code to Figma — Authenticate via the Model Context Protocol (MCP) integration.
3. Run your app — Open the UI you want to capture in your browser.
4. Trigger the capture — In Claude Code, type "Send this to Figma" to capture the current UI state.

**How the Code-to-Figma Workflow Works**

1. You build or prototype UI in Claude Code and view it in the browser.
2. You capture the screen state with the "Send this to Figma" command.
3. Claude Code sends the rendered UI to Figma via the MCP integration.
4. Figma creates a fully editable frame that designers and engineers can explore together.

Once in Figma, the design becomes a shared artifact where teams can organize flows, duplicate screens, compare alternatives, annotate decisions, and collaborate without requiring everyone to run the app locally.

**What Are the Limitations?**

- One-way capture: The captured design doesn't automatically sync back into source code.
- No automatic round-trip: Editing in Figma doesn't rewrite your code base by itself.
- Not full design system output: It doesn't auto-generate components, tokens, variables, or style systems.
- Animations and complex interactions: These won't translate; only static UI states are captured.

**Why This Matters for Developers**

For engineers, this feature offers concrete benefits:
- Eliminate manual recreation of implemented screens in Figma
- Get design feedback earlier on real UI states
- Explore multiple UI variants visually without rebuilding them by hand
- Improve alignment across design and engineering by sharing real UI artifacts, not screenshots`,
   link:"https://www.figma.com/blog/introducing-claude-code-to-figma/"},
  {id:23,date:"2026-02-20",author:"Victor Zhinzherov",tags:["Infrastructure","Google","NVIDIA"],emoji:"⚙️",
   title:"Google TPU vs NVIDIA GPU: The Infrastructure War Behind Every AI Model",
   summary:"While we debate Gemini vs GPT vs Claude, Google is playing a different game: owning the silicon. Control of the cost curve may matter more than today's benchmarks.",
   body:`Over the past year, we've been obsessing over models: GPT-5.x, Claude Opus, Gemini 3.x. Benchmarks go up, context windows expand, multimodality improves. But underneath every impressive demo is something far less glamorous — and far more decisive: Silicon.

**What Is a GPU?**

A GPU (Graphics Processing Unit) was originally built for rendering graphics. But GPUs turned out to be extremely good at massive parallel computation and matrix multiplications — exactly what transformer models need.

Modern LLMs are essentially giant matrix multiplication systems operating across billions or trillions of parameters. GPUs became the default engine that made this possible. That's why OpenAI, Anthropic, xAI, and Meta all rely heavily on NVIDIA GPUs (A100, H100, etc.) for both training and inference.

But GPUs are expensive, supply is limited, NVIDIA controls the ecosystem (CUDA, drivers, tooling), and every frontier lab competes for the same hardware. The AI race is, in many ways, a GPU allocation race.

**What Is a TPU?**

A TPU (Tensor Processing Unit) is Google's custom-built AI accelerator. Unlike GPUs, which are general-purpose parallel processors, TPUs were designed specifically for neural network workloads.

TPUs are optimized for large-scale transformer training, high-throughput matrix operations, distributed training across thousands of chips, and high-bandwidth interconnect inside TPU pods.

Most importantly: Google designs them, deploys them, and runs Gemini on them. That's vertical integration at the infrastructure level.

**Why This Matters for Frontier Models**

When Google builds Gemini, they can:
- Co-design the model architecture with the hardware
- Optimize software frameworks directly for TPU
- Scale without competing in the open GPU market
- Avoid being exposed to NVIDIA's pricing dynamics

**The Deeper Question**

We usually frame AI competition as Gemini vs GPT vs Claude. But there's another axis: Google Silicon vs NVIDIA Silicon.

In frontier AI, model intelligence scales with compute, compute scales with hardware access, hardware access shapes economics, and economics shape survival.

**Final Thought**

When we see "Gemini 3.1 just dropped and it's impressive," we should also ask: What infrastructure made this possible? How sustainable is that compute? Who controls the cost curve? Who captures the margin?

In the long run, AI leadership may not just belong to the company with the smartest model. It may belong to the company that can scale intelligence without being crushed by its own infrastructure bill. The model war is visible. The silicon war is not. But it might decide everything.`,},
  {id:24,date:"2026-02-19",author:"Victor Zhinzherov",tags:["Google","Gemini","Model Release"],emoji:"🧬",
   title:"Gemini 3.1 Pro: Stronger Reasoning, 1M Token Context, Available in Cursor",
   summary:"Gemini 3.1 Pro is an engineering-focused iteration: improved multi-step reasoning, 1M token context, and better software engineering tasks. Not a rebrand — a refinement focused on thinking better.",
   body:`On February 19, 2026, Google officially announced Gemini 3.1 Pro, the latest upgrade to the Gemini 3 Pro model.

This is not a brand-new model family. It's an iteration focused on improving reasoning quality and developer workflows.

**What Was Improved in Gemini 3.1 Pro**

1. Stronger Reasoning — Google emphasizes improved multi-step reasoning and logical consistency. Better step-by-step problem solving, more coherent long answers, fewer logical jumps in complex tasks. This is especially relevant for architecture discussions, refactoring plans, debug reasoning, and multi-stage workflows.

2. Large Context Support (Up to 1M tokens) — Gemini 3.1 Pro supports up to 1 million tokens of context in a single request. To make that more concrete:
- ~750,000 words of text
- Roughly 8–10 average-sized novels
- A very large multi-file codebase
- Massive log files or long technical documentation

This means you can send entire repositories, multiple services worth of code, long debugging sessions with full context, or full API specs + implementation + logs together — without needing aggressive chunking strategies.

3. Software Engineering Optimization — Google explicitly mentions improvements for software engineering tasks, tool usage, structured outputs, and agent-style workflows.

**What This Means for Us as Developers**

Realistically, this could improve:
- Multi-file reasoning in large projects
- Refactoring suggestions that require broader context
- Debugging flows that require step-by-step thinking
- More stable responses in long technical prompts

The key shift is not speed. It's reasoning stability and coherence.

**Gemini 3.1 Pro is Also Available in Cursor**

Gemini 3.1 Pro has already been added as a selectable model in Cursor. If anyone experiments with it in real projects, would love to hear practical feedback.

**Bottom Line**

Gemini 3.1 Pro is an upgrade focused on reasoning quality, designed for complex tasks and engineering workflows, context-heavy friendly, and available via API and inside Cursor. It's a refinement focused on thinking better, not just responding faster.`,
   link:"https://blog.google/innovation-and-ai/models-and-research/gemini-models/gemini-3-1-pro/"},
];
const POSTS_PART2 = [
  {id:25,date:"2026-02-18",author:"Victor Zhinzherov",tags:["Anthropic","Claude Code","Deep Dive"],emoji:"🔧",
   title:"Claude Code — Why So Many Senior Engineers Swear By It",
   summary:"Claude Code is not just another model toggle in Cursor. It's optimized for reasoning depth — large refactors, architecture planning, complex debugging across files.",
   body:`Most of us use Cursor daily. It's fast, integrated, and honestly great for our workflow.

But recently there's been serious buzz around Claude Code specifically — not "Claude chat," not "Claude API," but the full Claude Code experience. Some of us already have a Claude Pro subscription. If you do, I strongly encourage you to actually try Claude Code and compare it on real tasks.

**What Is Claude Code (And What It's NOT)**

Claude Code is not just the Claude model. It's a dedicated coding environment powered by Anthropic's full Claude reasoning system, optimized for deep software engineering tasks.

It is designed for: large codebase reasoning, multi-file understanding, safe refactors, migration planning, architecture-level thinking, and structured code reviews.

Most IDE-integrated models are optimized for speed and short interactions. Claude Code is optimized for reasoning depth. That difference matters.

**Cursor vs Claude Code — What's the Real Difference?**

Cursor is an IDE. It supports multiple models. Models inside IDEs are optimized for speed and inline interaction, designed for short reasoning bursts and autocomplete. Cursor is excellent for fast iterations, inline edits, autocomplete, and small scoped changes. It feels like an AI pair programmer.

Claude Code is not just another model toggle. It's optimized for reasoning-first, deep reasoning, long context stability, multi-step structured analysis, and cross-file understanding. It feels more like a senior engineer reviewing and thinking through your system.

**Where Claude Code Shines (Real Developer Use Cases)**

Large Refactors: Provide entire service, related files, supporting types. Ask "Propose a clean modular refactor while preserving behavior." Claude Code typically extracts logical boundaries, preserves functionality carefully, suggests clearer abstractions, flags risky edge cases, and explains its reasoning.

Architecture & Migration Planning: Provide existing flow, DB schema, event system, business constraints. Ask "Design a safe incremental migration plan." Claude Code breaks it into phases, identifies breaking points, flags hidden coupling, suggests rollback strategy.

Complex Debugging: Provide multiple related files, logs, error traces. Claude Code traces state across files, identifies mutation issues, spots potential race conditions, and explains causal chains clearly.

**How Claude Code Fits Into Daily Development**

Writing Cleaner First Drafts: Ask "Implement X with proper validation and typed responses." Claude Code structures modules cleanly, separates concerns, uses consistent naming, and anticipates edge cases.

Safer Refactoring: Ask "Refactor for readability without changing behavior." Claude Code preserves logic carefully, extracts helpers properly, improves naming, and avoids subtle regressions.

Understanding Legacy Code: Paste 2–3 related files. Claude Code explains flow clearly, identifies hidden assumptions, highlights unclear abstractions, and suggests improvements.

**Proposal**

If you already have Claude Pro: pick one real task — large refactor, complex bug, PR review, migration design. Run it through both Cursor and Claude Code. Compare structure, edge case awareness, refactor safety, and clarity of reasoning.

Let's evaluate based on engineering output, not hype.`,},
  {id:26,date:"2026-02-15",author:"Victor Zhinzherov",tags:["AI Agents","Architecture","OpenClaw"],emoji:"🦞",
   title:"OpenClaw: Understanding the Architecture Behind Autonomous AI Agents",
   summary:"OpenClaw moves the execution loop from backend code into the agent runtime. This is an execution topology shift — the real question is where the loop should live and how to bound it.",
   body:`As AI systems move from simple prompt-response interactions to multi-step task execution, a new architectural pattern is emerging. One example is OpenClaw — an open-source framework designed to build AI agents that can plan, act, reflect, and iterate with minimal human intervention.

This isn't about a new model or smarter AI. It's about changing how we structure control flow in AI systems. In simple terms, this is an execution topology shift — the loop that controls iteration moves from our backend code into the agent runtime itself.

**What Is an Execution Loop?**

In software engineering, an execution loop is a repeated control structure that continues running until a condition is met.

In traditional backend systems: we write the loop, we define the stop condition, we control retries, handle errors, log every step, and we own the lifecycle.

In most LLM applications today, if we need iteration, we manually orchestrate — call model, parse output, decide next step, call again, stop when satisfied. The loop is external. It lives in our backend code.

**What OpenClaw Changes**

OpenClaw embeds the execution loop inside the agent runtime. Instead of us writing:
while (!done) { plan(); act(); reflect(); }

The agent internally runs: Observe → Plan → Act → Reflect → Repeat → Stop

The LLM decides what to do next, calls tools, evaluates results, re-plans if needed, and terminates when it believes the task is complete. The orchestration becomes model-driven. That's the key architectural shift.

**What Is OpenClaw Exactly?**

OpenClaw is an open-source autonomous agent framework that:
- Connects an LLM to tools (browser, files, APIs, shell, messaging apps)
- Maintains state across steps
- Runs iterative reasoning loops
- Allows multi-step task completion without external orchestration

It doesn't introduce new intelligence. It structures how intelligence is applied over time.

**Why This Matters Architecturally**

Traditionally: Deterministic Code → Controls AI
With OpenClaw-style agents: Probabilistic AI → Controls Code Execution

This enables more flexible workflows, complex task chaining, and adaptive behavior — but also introduces tradeoffs:
- More iteration = more tokens and latency
- Cost scales with reasoning depth
- Loop depth can become unpredictable without bounds
- Observability becomes harder if execution paths are emergent

Production systems need: explicit guardrails, structured telemetry, deterministic validation layers, and clear fallback mechanisms.

**Final Takeaway**

OpenClaw is not a smarter model. It's an architectural shift: moving execution loops from backend code into the agent runtime.

The real engineering question isn't "Is this autonomous?" It's: Where should the loop live, and how do we bound it responsibly?`,
   link:"https://medium.com/@yaron.genad/openclaw-in-production-engineering-reality-beyond-the-hype-671763d9c728"},
  {id:27,date:"2026-02-11",author:"Victor Zhinzherov",tags:["OpenAI","ChatGPT","Research Tools"],emoji:"🔍",
   title:"Deep Research in ChatGPT Gets a Major Upgrade — Now Powered by GPT-5.2",
   summary:"Deep Research shifts from one-shot query to iterative collaboration: review the plan before it starts, guide scope, interrupt mid-run. New full-screen workspace.",
   body:`OpenAI has officially rolled out a major update to Deep Research in ChatGPT as of February 10, 2026.

This update upgrades the underlying research engine, redesigns the reading experience, and gives users significantly more control over how research is conducted. Unlike the initial Deep Research launch, which focused on introducing autonomous web research, this release focuses on quality, usability, and professional workflows.

**What's New**

This release introduces three meaningful improvements:
1. Deep Research now runs on GPT-5.2
2. Research results open in a new full-screen workspace
3. Users have more control before and during research

**1. GPT-5.2 Upgrade (Core Engine)**

What this improves in practice:
- Stronger reasoning across many sources: The model can better compare information, detect inconsistencies, and connect related ideas.
- More consistent long-form outputs: Long reports are less likely to drift, contradict themselves, or lose structure midway.
- Better synthesis instead of surface summaries: Instead of summarizing each source separately, the model does a better job merging insights into a cohesive narrative.
- Improved logical flow: Reports feel more structured and easier to follow.

**2. New Full-Screen Research Workspace**

Research results now open in a dedicated full-screen document view, with a side table of contents for jumping between sections, clear section hierarchy, and a dedicated sources panel for reviewing where information came from.

**3. More Control Over the Research Process**

You can now:
- Review and edit the research plan before it starts
- Guide the scope toward specific domains or sources
- Track progress while it runs
- Interrupt and adjust mid-run without restarting from scratch

Previously, Deep Research felt like a one-shot query. Now it feels more like collaborating with a research assistant.

**Why This Matters for Developers**

- Better technical deep dives when researching frameworks, SDK behavior, or distributed system patterns
- Stronger tool and library comparisons
- Cleaner input for design docs and ADRs
- More effective spike investigations
- Improved research transparency

In short, this update makes Deep Research more aligned with how developers actually work: iterative, structured, and evidence-based.`,
   link:"https://chatgpt.com/features/deep-research/"},
  {id:28,date:"2026-02-09",author:"Victor Zhinzherov",tags:["AI Economics","Industry","Analysis"],emoji:"💰",
   title:"The AI Reality Check: When Engineering Meets Economics",
   summary:"The 'improvement paradox': better models require more compute, which requires more money, which requires better models. The whole industry runs on investor confidence. And yes, ads are coming to AI.",
   body:`We're usually here to geek out on the technical side of things: new architectures, Agents, LLMs, MCPs, and shiny frameworks. But there's another side of the story that doesn't show up in benchmarks: AI is getting better and better, while the companies building it are fighting a brutal financial battle to keep improving it.

**1) The "Improvement Paradox" (the treadmill)**

This is the engine behind the whole industry, and it's a dangerous loop. To justify massive valuations, these companies need to keep showing progress, but progress isn't linear. Making a model 10% better doesn't mean spending 10% more. It can mean dramatically more compute, more data, more infrastructure, and more iteration.

So they're stuck on a treadmill:
- To make money, they need better models.
- To build better models, they burn billions.
- To burn billions, they need to raise more money.
- To raise more money, they need… better models.

**2) Compute hunger isn't slowing down — it's getting pricier**

xAI just raised $20B in an upsized Series E round, explicitly framed around accelerating progress and scaling what's needed to build advanced AI. The arms race is still, fundamentally, an infrastructure race — and the bill keeps getting larger. This matters because it shapes everything downstream: pricing models, tiering, rate limits, routing to smaller models by default, and the relentless obsession with efficiency techniques.

**3) This is why the job market panic was overhyped**

A lot of the "AI will replace engineers next year" panic assumed AI would become cheap and infinite very quickly. But AI isn't cheap and it isn't infinite. It is resource-constrained, capacity-constrained, and cost-constrained.

Instead of "replace everyone soon," a more realistic trajectory is: human + AI collaboration keeps expanding, "AI does the easy/boring parts" grows fast, and full replacement stays harder and slower than the hype suggested.

**4) The part people miss: the whole industry runs on confidence**

There is a huge difference between "the technology works" and "there is a proven business model that produces durable profit." Right now, a lot of the market is pricing these companies on future outcomes — that their technology leadership will eventually translate into margins — even while today's economics remain heavy and uncertain.

**5) And yes… we're probably going to see ads in AI**

OpenAI has publicly said it plans to test advertising in the U.S. for ChatGPT's Free and Go tiers, while keeping higher tiers ad-free. At the same time, Anthropic has made a point of saying Claude will remain ad-free, arguing that ads inside an assistant warp incentives and erode trust.

That contrast is the economics debate in product form: one path tries to subsidize access with ads, the other tries to preserve trust by keeping the channel clean and charging directly.

**Bottom line**

The technology works, and we probably will keep seeing genuinely "wow" launches — partly because the breakthroughs are real, and partly because shipping impressive progress is how these companies defend valuations and keep fundraising.

We should keep learning, keep building, and keep leaning into AI, while staying clear-eyed about the constraints and skeptical of the idea that we're one quarter away from AI effortlessly replacing all engineers.`,
   link:"https://www.youtube.com/watch?v=A4q42Clnl0M"},
  {id:29,date:"2026-02-06",author:"Victor Zhinzherov",tags:["OpenAI","Codex App","Tools"],emoji:"🖥️",
   title:"Introducing the Codex App: Parallel Agents, Git Worktrees, and Voice Mode",
   summary:"The Codex Mac app enables parallel worktrees, a native 'Skills' library (like MCP), and voice Technical Dictation mode. This shifts AI from co-creation to delegation.",
   body:`Hey team, we need to talk about the Codex App (macOS) that quietly dropped this week.

If you're still using ChatGPT in the browser or even the Cursor sidebar, you are technically "single-threading" your AI. The new standalone app changes the game by letting you run Parallel Agents. It feels less like an IDE extension and more like you've just hired a team of three junior devs that you supervise from a dashboard.

**1. The "Killer Feature": Parallel Worktrees**

Because the app integrates deep into git, it can spin up isolated worktrees for different agents.

- Agent A: "Refactor the Auth login flow" (Branch: feat/auth-refactor)
- Agent B: "Write Cypress tests for the new checkout" (Branch: test/checkout)
- You: Reviewing Agent A's diffs while Agent B runs in the background.

They don't conflict. They don't overwrite your current open file. You just merge them when they turn green.

**2. "Skills" & The New Autonomy**

OpenAI has added a "Skills" library (similar to MCP but native). Instead of pasting instructions every time, you can bundle tools.

- The "Linear" Skill: reads the ticket in Linear, grabs the requirements, links the PR, and updates the status.
- The "Figma" Skill: pulls design tokens directly from the Figma file to ensure the CSS matches exactly.
- The "Deploy" Skill: runs a deployment to Vercel and reports back the URL.

**3. Voice Mode: The "Manager" Interface**

This is why the app feels different. The new "Technical Dictation" mode is built for high-level direction. You don't dictate code line-by-line. You dictate intent. You can lean back, look at the diff, and say: "Reject this file. You missed the edge case where the user is null. Re-run the test suite and ping me."

**4. Codex inside Cursor (The "Lite" Version)**

If you don't want to install a separate app, you can still access the core engine via the Codex Extension for Cursor. What you get: the full gpt-5.3-codex model available in chat/composer. What you miss: you lose the Parallel Worktrees.

Best for: Use the extension when you are writing complex logic yourself and just need a smart pair programmer. Use the App when you want to delegate tasks entirely.

**The Catch**

- Mac Only (For now): Windows/Linux users are stuck with the CLI for at least another few weeks.
- "Eager" Commits: The integration with Git is aggressive. If you aren't careful with permissions, an agent might commit a "fix" that breaks your linting rules. Review every diff.
- UI Glitches: It's a v1.0 product. Users are reporting weird window centering bugs and occasional crashes when the "Deep Research" agent runs too long.

**Verdict**

Download if: You are a Tech Lead or Senior Dev who knows exactly what needs to be done but hates doing the boilerplate. The "Manager" workflow of spinning up 3 agents to do the grunt work is a superpower.

Stick to Cursor if: You are "in the zone" writing complex logic yourself. The Codex App is for delegation; Cursor is for co-creation.`,
   link:"https://openai.com/index/introducing-the-codex-app/"},
  {id:30,date:"2026-02-06",author:"Victor Zhinzherov",tags:["OpenAI","GPT-5.3-Codex","Model Release"],emoji:"⚡",
   title:"GPT-5.3-Codex: The Hyper-Fast Collaborator — And It Helped Build Itself",
   summary:"OpenAI's GPT-5.3-Codex is the first model used to debug its own training runs. It's ~25% faster than 5.2. Best for fast iteration; Claude Opus 4.6 is better for architecture.",
   body:`Hot on the heels of Anthropic's release, OpenAI dropped GPT-5.3-Codex (Feb 5), and the philosophy is completely different.

If Opus 4.6 is the "deliberate architect" that thinks silently for minutes, Codex 5.3 is the "hyper-fast collaborator" that you steer in real-time.

The headline feature: OpenAI confirmed this is the first model "instrumental in creating itself" — it was used to debug its own training runs and manage its own deployment clusters.

**Opus 4.6 vs Codex 5.3: The TL;DR**

- Claude Opus 4.6: "I will sit in a room, think for 5 minutes, and hand you the perfect blueprint."
- GPT-5.3-Codex: "I will type at 200wpm, make mistakes, fix them instantly, and we'll be done in 2 minutes."

**The "Codex App" & CLI Changes**

Interactive Steering: Unlike Opus, which locks you out while it "thinks," Codex 5.3 is designed to be interrupted. You can watch it code in the new Codex App (macOS) and nudge it ("no, use a different library") while it's typing, without breaking its context.

The "Self-Healing" Loop: In the CLI, it doesn't just run code; it monitors the process table. If a build hangs or a port is blocked, it kills the process and retries automatically.

Terminal-Bench 2.0 King: It hit 77.3% on the Terminal-Bench 2.0 benchmark (edging out Opus 4.6's score from yesterday), largely because it's faster at iterating through errors rather than planning the perfect shot upfront.

**Codex 5.3 in Cursor**

This model is roughly 25% faster than GPT-5.2. In Cursor, it feels snappy. It's better for "iterative hacking" — building a feature, breaking it, and fixing it rapidly.

"Collaborative" Mode: OpenAI has tuned the model to ask for permission only on high-stakes changes (like deleting DB tables) but to be aggressive on safe changes (refactoring, linting).

**When to use what?**

- Use Claude Opus 4.6 for: System architecture, complex debugging, writing one-shot documentation, and "measure twice, cut once" tasks.
- Use Codex 5.3 for: Grinding through JIRA tickets, writing unit tests, scaffolding React components, and "fixing it live."`,
   link:"https://openai.com/index/introducing-gpt-5-3-codex/"},
  {id:31,date:"2026-02-06",author:"Victor Zhinzherov",tags:["Anthropic","Claude","Model Release"],emoji:"🌟",
   title:"Introducing Claude Opus 4.6: Adaptive Thinking and Agent Teams",
   summary:"Anthropic's flagship with 'Adaptive Thinking' — pauses to plan and reason before writing code. Top scores on BrowseComp/DeepSearchQA. Agent Teams in Claude Code CLI.",
   body:`Anthropic just released Claude Opus 4.6 (launched Feb 5), and it's a massive shift. This isn't just a simple model upgrade — they have fundamentally redefined how the model works with a new engine called 'Adaptive Thinking.'

Instead of rushing to output text, Opus 4.6 now pauses to plan, reason, and architect solutions before writing a single line of code.

**Claude Code (CLI) Changes**

This is where the heavy engineering updates are.

Agent Teams (Research Preview): You can now spin up multiple "sub-agents" to work in parallel. Think: one agent writing tests while another refactors the implementation, all coordinating autonomously.

Better Control: New controls (like Shift+Up/Down and tmux support) to take over specific sub-agents manually if they get stuck.

Local Dev Autonomy: The model is significantly better at "long-horizon" tasks — it can identify blockers, run tools, and debug its own code without needing constant hand-holding.

SOTA Agentic Coding: Highest scores on Terminal-Bench 2.0, specifically designed to test these real-world CLI workflows.

**Claude Code (For Cursor Users)**

Available Now: You can select claude-opus-4-6 in the model picker (requires Cursor v2.1.32+).

"Collaborator" vs. "Code Generator": Early reports suggest this model behaves more like a senior engineer — it thinks longer, asks clarifying questions, and excels at complex architecture/debugging rather than just spitting out boilerplate fast.

Cost Warning: Because of the "Adaptive Thinking" (where it generates hidden thought tokens), it can burn through your token quota significantly faster than 3.5 Sonnet. Use it for the hard stuff (architecture, deep bugs), NOT for simple "fix this typo" tasks.

No "Agent Teams" in GUI: The multi-agent "Teams" feature is currently specific to the Claude Code CLI tool, not the Cursor IDE interface itself.

**Web & Workflow Changes**

"Deep Search" Capability: Opus 4.6 is currently unmatched in browsing and retrieving hard-to-find info (Top scores on BrowseComp and DeepSearchQA).

1M Token Context (Beta): Finally available for the Opus class on the web/API, allowing for massive document analysis without losing coherence.

128k Output Limit: Output tokens have been doubled (up from 64k), allowing for much larger code files or reports in a single pass.

**Technical & API Specs**

Adaptive Thinking: The budget_tokens parameter is deprecated. You now use thinking: { type: "adaptive" } paired with an effort level (low, medium, high, max). The model dynamically adjusts how much reasoning to apply.

Context Compaction: For long threads, the API can now automatically summarize older context to preserve "working memory" without hitting token limits.

**When can we use it?**

Available Now: It is live on the API (claude-opus-4-6), Claude.ai (Pro/Team/Enterprise), Amazon Bedrock, and Google Vertex AI.

Previews: The "Agent Teams" in Claude Code and the PowerPoint integration are in research preview.`,
   link:"https://www.anthropic.com/news/claude-opus-4-6"},
  {id:32,date:"2026-02-03",author:"Victor Zhinzherov",tags:["Google","Chrome","Gemini"],emoji:"🌐",
   title:"Chrome v144+ Gets Gemini 3 Auto Browse: Agentic AI Baked Into the Browser",
   summary:"Google's biggest Chrome update: Auto Browse (Gemini 3) can autonomously navigate the web and complete tasks. DevTools gets AI console insights. Persistent Gemini side panel reads across all open tabs.",
   body:`I want to highlight a major shift in the latest Chrome update (v144+). Google isn't just adding a chatbot — they are rolling out agentic AI capabilities directly into the browser.

**The "Agentic" Shift (Auto Browse)**

The biggest update is Auto Browse (powered by Gemini 3). It goes beyond a chatbot — it can autonomously navigate the web to finish tasks.

What it looks like: You give it a goal (e.g., "Find a hotel in Chicago for under $200 and book it"), and it opens tabs, filters results, and fills out forms while you watch.

How it works: It autonomously opens tabs, clicks links, filters results, and even manages forms. It shows a real-time log of its actions in the sidebar. It requires manual confirmation for sensitive actions (like "Buy" or "Post") and has a "Take over task" button if you need to intervene.

Architecture: Uses the Universal Commerce Protocol (UCP) to standardize interactions with shopping sites like Shopify and Etsy.

**DevTools Upgrades**

This is what will actually save us time during debugging.

Console Insights: If you hit an error in the console, you can now right-click to get an AI explanation of the stack trace and potential fixes.

CSS Assistant: The Elements panel now has an AI helper. You can ask questions like "Why is this grid misaligned?" and it analyzes the computed styles to tell you exactly which rule is breaking the layout.

**Persistent Gemini Side Panel**

The floating window is gone — it's now a fixed side panel designed for multitasking. It can "see" all your open tabs, so you can ask it to cross-reference info between them (e.g., "Compare the pricing on these 3 tabs").

**Connected Workspace**

Gemini in Chrome can now pull context from your Gmail, Calendar, and Drive to answer queries (e.g., "When is my next flight?" pulls from your email confirmation).

**When do we get it?**

The Dev Features: Rolling out globally in the latest Stable build. The Agentic Features: Rolling out gradually, starting with US subscribers first. Currently rolling out to AI Premium subscribers in the US.`,
   link:"https://www.google.com/chrome/?linkId=44079487"},
  {id:33,date:"2026-02-01",author:"Tony Dolev",tags:["Link","Resource"],emoji:"🔗",
   title:"Moltbook — Worth Checking Out",
   summary:"Tony shared a link to moltbook.com.",
   body:`https://www.moltbook.com/`,
   link:"https://www.moltbook.com/"},
  {id:34,date:"2025-12-18",author:"Benji Amram",tags:["Cursor","Debugging","Tools"],emoji:"🐛",
   title:"Cursor v2.2 Debug Mode: Hypothesis-Driven Bug Fixing",
   summary:"Debug Mode in Cursor 2.2 instruments code with logging, asks you to reproduce the bug with real runtime data, then proposes a targeted fix. Best for stubborn, hard-to-pinpoint bugs.",
   body:`Cursor just released Debug Mode as part of the 2.2 update — and it's a powerful new way to diagnose and fix bugs more effectively right inside your editor.

**What Debug Mode Does**

Debug Mode introduces a structured agent loop built around runtime logs and human verification. Instead of jumping straight to a patch, the agent:

1. Reads your codebase and generates multiple hypotheses about what might be going wrong. This is the best part — instead of immediately generating a fix, it actually reasons about causes.
2. Instruments your code with logging statements to capture runtime information like variable states and execution paths.
3. Asks you to reproduce the bug so it can analyze real runtime data.
4. Proposes a targeted fix and then asks you to verify the fix before stripping out the logs and finalizing it.

The result? Instead of hundreds of speculative lines, you often get precise fixes based on real execution context.

**When to Use It**

- For stubborn or hard-to-pinpoint bugs
- When previous agent passes didn't yield good results
- When you want better insight into why something is breaking, not just what the output is

**How to Get Started**

- Select Debug Mode from the mode dropdown
- Describe the bug in detail
- Follow the agent's prompts to reproduce the issue
- Verify and mark the fix once you've confirmed it's resolved

This feature works across languages and stacks and is designed to mirror real developer debugging workflows with AI assistance.`,
   link:"https://cursor.com/blog/debug-mode"},
  {id:35,date:"2025-12-16",author:"Tamir Tubul",tags:["Google","Browser","Experimental"],emoji:"🍋",
   title:"Google Disco: An AI-First Browser That Builds Mini-Apps From Your Open Tabs",
   summary:"Google Labs dropped an experimental browser (macOS, invite-only) that uses Gemini 3 to generate 'GenTabs' — custom mini-apps built on the fly from your context.",
   body:`Have you seen Google's new "Disco" browser?

Google Labs just dropped an experimental AI-first browser called Disco. It's not just a Chrome wrapper; it's an attempt to reimagine the browser as a tool builder rather than just a page viewer.

**The Killer Feature: GenTabs**

Instead of just opening tabs, Disco uses the new Gemini 3 model to analyze your open tabs/context and build custom mini-apps (called GenTabs) on the fly.

- Example: If you have tabs open for flights, hotels, and blogs about Japan, it generates a unified "Japan Trip" dashboard with a map, itinerary, and budget tracker.
- Example: Researching a complex topic? It builds a study guide app with quizzes and summaries.

**Under the Hood**

- Engine: Built on Chromium (so it feels familiar).
- AI: Powered by Gemini 3 (multimodal, high reasoning).
- Philosophy: Moves from "Search & Sift" → "Context & Build."

**Status:** It's currently an experimental project via Google Labs (macOS only for now) and is invite-only.

Hot take: It looks like a direct answer to the "browser-as-an-OS" trend (like Arc) but with a focus on generative UI. Instead of organizing tabs, Disco turns them into tools. Instead of searching for information, it synthesizes it into something interactive.`,
   link:"https://labs.google/disco"},
  {id:36,date:"2025-12-16",author:"Victor Zhinzherov",tags:["Datadog","MCP","Cursor"],emoji:"🐶",
   title:"Apartment List Added to Datadog MCP Closed Preview — Here's How to Set It Up",
   summary:"Apartment List is now on the Datadog MCP Server preview list. Setup: add config to mcp.json, install the Datadog Cursor extension, sign in to US1, authorize with your work email.",
   body:`Excited to share that Apartment List has officially been added to the MCP Server preview closed list, which means you can now use Datadog MCP in Cursor.

**How to get Datadog MCP working?**

1. Confirm you have the Datadog MCP configuration in your mcp.json file in Cursor.
2. Install the Datadog Cursor extension (this is required).
   - Sign in to Datadog through the extension.
   - DataDog Sites: Choose the first option, US1 (app.datadoghq.com)
   - When the authorization window appears, click "Authorize as XXX@apartmentlist.com" at the bottom.
3. You're all set — Datadog MCP should now be available in Cursor.

Big thanks to Alex Lee for reaching out to Datadog and helping us get added to the closed preview list.

**What you can do with Datadog MCP in Cursor**

Once configured, you can ask Claude or another model in Cursor to:
- Query your Datadog logs directly from the editor
- Look up metrics and dashboards without leaving your workflow
- Cross-reference application errors with log data in the same conversation
- Troubleshoot production issues with real observability data alongside your code

This is a significant workflow improvement — instead of switching between your editor, browser, and Datadog, you can ask questions about your production environment directly while looking at the relevant code.`,},
  {id:37,date:"2025-12-12",author:"Victor Zhinzherov",tags:["OpenAI","GPT-5.2","Model Release"],emoji:"🚨",
   title:"GPT-5.2: OpenAI's 'Code Red' Response to Gemini — Accelerated by Weeks",
   summary:"OpenAI issued an internal code red memo and fast-tracked GPT-5.2 in response to Gemini competition. SOTA on GDPval. Four modes: Instant, Thinking, Pro, and Auto.",
   body:`OpenAI has officially announced its GPT-5.2 upgrade to ChatGPT. This release is widely described as a "code red" response to Google Gemini, and OpenAI itself calls GPT-5.2 its most capable model series yet for professional knowledge work.

The announcement follows reports that OpenAI accelerated the GPT-5.2 release by several weeks in response to recent Gemini model improvements. According to those reports, an internal "code red" memo was issued, pushing the model to production faster than originally planned.

**What's inside GPT-5.2**

"We designed GPT-5.2 to unlock even more economic value for people. It's better at creating spreadsheets, building presentations, writing code, perceiving images, understanding long contexts, using tools, and handling complex, multi-step projects."

"GPT-5.2 sets a new state of the art across many benchmarks, including GDPval, where it outperforms industry professionals at well-specified knowledge work tasks spanning 44 occupations."

**Model Modes**

GPT-5.2 introduces clearer usage modes inside ChatGPT:
- Instant — fast responses for everyday questions
- Thinking — deeper reasoning for complex problems
- Pro — highest accuracy for demanding or research-heavy tasks
- Auto — mode that switches between Instant and Thinking automatically based on task complexity

**Key Improvements Worth Calling Out**

1. Stronger Reasoning for Complex Work: Performs noticeably better on multi-step tasks, structured problem-solving, and long workflows where consistency and correctness matter.

2. Better at Professional Outputs: Clear gains when working with spreadsheets and structured data, presentations and documents, code generation and refactoring, and long technical or business contexts.

3. Larger Context Understanding: GPT-5.2 can handle much longer conversations and documents, making it more reliable for projects that require maintaining context over time.

4. Improved Tool Usage and Vision: Tool-calling, image understanding, and end-to-end task execution have all improved, making the model better suited for agent-like workflows.

**Availability**

Release date: December 11. Rolling out gradually to paid users on Plus, Pro, Go, Business, and Enterprise plans. GPT-5.1 will remain available as a legacy model for three months, after which it will be sunset.`,
   link:"https://openai.com/index/introducing-gpt-5-2/"},
  {id:38,date:"2025-12-11",author:"Victor Zhinzherov",tags:["Cursor","Visual Editor","UI"],emoji:"🎨",
   title:"Cursor 2.2: A Visual Editor for the Cursor Browser — Drag, Prompt, Ship",
   summary:"Cursor now connects the UI, the code-editing agent, and a WYSIWYG editor in one loop. Drag-and-drop layout, component prop controls, visual style sliders — all feed back into the codebase.",
   body:`Cursor shipped today (December 11) a visual editor for the Cursor Browser.

This is a big shift for anyone working with UI components: Cursor is now effectively connecting the UI, the code-editing agent, and a WYSIWYG-like editor in one loop. You can change the interface visually, and the agent translates those changes back into code.

You can now drag elements around on the page, tweak component props and styles from a sidebar, and even click on an element and describe the change you want in natural language — the Cursor agent takes care of updating the underlying code.

Once you've selected a component, you can also ask the agent questions about it (for example, to find the related code, see how it's wired up, or understand its props), and it will jump you to what you need.

**What it can do**

- Drag-and-drop layout: Rearrange elements in the DOM visually — swap buttons, reorder sections, try different grid layouts, then let the agent apply those changes back to the code.
- Work at the component level: For React apps, the editor surfaces component props in a sidebar so you can flip variants and states without hunting through stories or one-off routes.
- Visual style controls: Adjust colors, typography, grids, and flexbox layouts with sliders, palettes, and design tokens. Changes are interactive and previewed live.
- Point and prompt: Click an element and ask things like "make this bigger," "turn this red," or "swap their order." Agents run in parallel and update the underlying code.

**Why it's interesting**

This pushes UI work up the abstraction stack: we describe the outcome in terms of layout and behavior, and let agents handle the mechanics of editing code. It also narrows the gap between design tools and the real product.

If you're curious, update to Cursor 2.2, open the Cursor Browser, enable the visual editor, and try dragging things around or prompting a few changes.`,
   link:"https://cursor.com/blog/browser-visual-editor"},
  {id:39,date:"2025-12-04",author:"Victor Zhinzherov",tags:["AWS","GCP","Multicloud"],emoji:"☁️",
   title:"AWS + GCP Partner on Multicloud Networking: Setup Time Goes From Weeks to Minutes",
   summary:"After major AWS and Azure outages, AWS and Google Cloud announced cross-cloud interconnect. Salesforce is the first adopter. True multicloud resilience is now operationally realistic.",
   body:`Over the last 2 months, many of us witnessed major global outages across the cloud world, including a massive AWS outage that disrupted thousands of services worldwide, followed shortly after by a widespread Azure outage. These events were a strong reminder of how deeply companies rely on a single cloud provider and how painful that dependency can be when things go wrong.

**AWS & GCP Announce a Joint Multicloud Networking Partnership**

AWS and Google Cloud announced a rare collaboration: They're each launching a service that lets organizations create fast, secure, private connectivity between AWS and GCP within minutes, without needing complex manual infrastructure setups.

Until now, if a company wanted to move large amounts of data or traffic between clouds, the process was painful and manual, expensive, and could take weeks to architect and deploy.

With this new partnership:
- Setup time goes from weeks → minutes
- Traffic is secure, private, and high-bandwidth
- True multicloud resilience becomes possible: If AWS is down, you can fail over to GCP without having to pre-build a giant multicloud network
- Workload movement becomes much easier

**How the Solutions Work**

Google Cloud – "Cross-Cloud Interconnect": GCP's service allows you to connect your Google VPC network directly to AWS using high-bandwidth links, low-latency routing, and secure, private IP communication. To GCP, your AWS subnets look like just another network attached to Google's global backbone.

AWS – "Multicloud with AWS Interconnect": AWS mirrors the approach: Their service lets you treat GCP workloads like another AWS region reachable through the AWS global network.

**Salesforce Becomes the First Adopter**

Salesforce is officially the first major enterprise to adopt this architecture. They now maintain active connectivity to both AWS and GCP using these new services, giving them higher resilience, faster data transfer, and more freedom to shift workloads when needed.

This shows the industry is already taking this collaboration seriously.`,
   link:"https://docs.cloud.google.com/network-connectivity/docs/interconnect/concepts/cci-overview"},
  {id:40,date:"2025-12-03",author:"Victor Zhinzherov",tags:["Google","Gemini 3","Cursor"],emoji:"🌟",
   title:"Gemini 3 Drops — Salesforce CEO Ditches ChatGPT, OpenAI Declares Code Red",
   summary:"Marc Benioff called Gemini 3 'an insane leap' and switched from ChatGPT after 3 years. With Apartment List Google accounts, we likely have Gemini 3 Pro access including Nano Banana tools.",
   body:`Quick AI news from the field.

Over the past few days, the AI race has heated up a lot. Salesforce CEO Marc Benioff publicly said he's ditching ChatGPT after three years of daily use and switching to Google's Gemini 3, calling it "an insane leap" in reasoning, speed, images, and video — "I'm not going back."

At the same time, multiple reports say Sam Altman has declared an internal "code red" at OpenAI, refocusing the company on improving ChatGPT and pausing some other projects, as competition from Google's Gemini 3 starts to bite.

**Why do we care?**

With our Apartment List Google accounts it looks like we have access to the Gemini 3 Pro dashboard app, plus Google's "Nano Banana" tools for images and video, which are getting a lot of buzz as top-tier multimodal generators.

You can also select Gemini 3 as a model in Cursor and try it on real coding tasks — it's a great opportunity to run the same workflows in both Gemini 3 and ChatGPT 5.1 and compare the results yourself.

**How to access it**

- Open your Apartment List Google account at gemini.google.com
- You should see Gemini 3 Pro as the default option
- In Cursor, look for Gemini 3 in the model picker and select it
- Try comparing it to Claude or GPT-5.1 on a real task — architecture review, complex refactor, or something you've been stuck on

Would love to hear how it compares on real engineering tasks. If you run an interesting comparison, share it in the channel.`,},
  {id:41,date:"2025-11-30",author:"Victor Zhinzherov",tags:["MCP","Presentation","Knowledge Share"],emoji:"📊",
   title:"MCP Knowledge Share Presentation Now Available",
   summary:"Victor shared the MCP Knowledge Share Google Slides deck — a comprehensive overview of the Model Context Protocol.",
   body:`Hi team, I'm sharing the MCP – Knowledge Share presentation.

This deck covers the Model Context Protocol (MCP), how it works, the MCPs we use at Apartment List, and how to get started. It's a great reference if you're new to MCPs or want to share the context with a teammate.

The Model Context Protocol is the standard that lets AI coding tools like Claude Code and Cursor communicate with external services — your GitHub repos, Jira tickets, Slack channels, Figma files, databases, and more. Instead of each tool building its own integration, MCP provides a shared protocol that both the AI tool and the external service can implement once.

The deck walks through:
- What MCP is and why it matters
- How MCP servers work (the architecture)
- The specific MCPs we have set up at Apartment List
- How to authenticate and get started
- Examples of real workflows we've unlocked

If you want to understand why Claude Code feels so much more powerful than just using Claude in the browser, MCPs are a big part of the answer.`,
   link:"https://docs.google.com/presentation/d/1nkvt7hN4ycAGYn5u0zbYIiWjDUQtEV7XR24Kim0TgH0/edit"},
  {id:42,date:"2025-11-26",author:"Victor Zhinzherov",tags:["MCP","Cursor","Toolbox"],emoji:"🧰",
   title:"Introducing the AI Nurture MCP Toolbox: 8 Integrations, One mcp.json",
   summary:"A single mcp.json file unlocks DataDog, Figma, GitHub, GCP/BigQuery, Jira, MongoDB, PostgreSQL, and Slack directly in Cursor. All remote — no manual installation.",
   body:`I'm excited to introduce the AI Nurture MCP Toolbox!

This toolbox bundles 8 commonly used MCP tools to support our day-to-day work directly in Cursor, so we rarely need to leave the editor:

- DataDog: Query logs and metrics directly from Cursor. Inspect dashboards and troubleshoot incidents faster.
- Figma: Search and open design files from within the editor. Pull component details, copy styles, and reference specs while coding.
- GitHub: Search repos, files, and code references. Look up PRs, issues, and reviews without leaving Cursor.
- GCP: Inspect resources (e.g., instances, buckets, services). Fetch BigQuery tables and run queries for data exploration and debugging.
- Jira: Search and open tickets by key or text. Check status, assignee, and details while you work.
- MongoDB: Run queries against collections from Cursor. Inspect documents and basic schema info for debugging.
- PostgreSQL: Run SQL queries against our databases. Inspect tables, schemas, and query results (VPN required).
- Slack: Search messages and channels for context. Send messages to any Slack channel.

The toolbox is essentially just a single mcp.json file, and all of its MCPs are remote — some use hosted URLs and some run as local processes, but none require manual installation. You just drop the mcp.json into Cursor and start using it, that's it.

**A few notes and caveats**

- DataDog: The Datadog MCP Server is currently in preview and not publicly available yet.
- GitHub: Each of you will need to create your own Personal Access Token (PAT).
- PostgreSQL: You must be connected to the VPN.
- Figma & Jira: The MCPs will ask you to authenticate once via your browser. This is a one-time login per tool.
- Slack: A dedicated Slack bot named ai-nurture-mcp was created. The only limitation: it can send Slack messages only by using a channel ID, not a channel name.

Please talk to me to get the mcp.json file — I can't post it here because it contains sensitive API keys.`,},
  {id:43,date:"2025-11-26",author:"Victor Zhinzherov",tags:["Node.js","JavaScript","LTS"],emoji:"🟢",
   title:"Node 24 LTS (Krypton): Native Fetch, Stricter Validation, Better Web APIs",
   summary:"Node 24 (LTS until April 2028) ships native fetch(), stable Web Streams API, stricter runtime validation, and new globals like CloseEvent and Float16Array.",
   body:`Node.js 24.x ("Krypton") is now in Long-Term Support (LTS). It was officially promoted to LTS on October 28, 2025, and will receive updates through April 2028.

**Why Node 24 LTS matters**

- Up-to-date compliance with current JavaScript ECMAScript standards
- Higher native module support
- New APIs that streamline everyday backend tasks
- Optimized security features and stricter defaults
- Improved performance — credit to the latest V8 JavaScript engine (v13.6)

**1. Native Fetch API Support**

One of the biggest Node.js 24 changes is its native Fetch API support, which simplifies HTTP requests and aligns the platform with the browser environment. No more depending on third-party libraries like node-fetch or Axios for basic HTTP calls.

const response = await fetch('https://api.example.com/data');
const data = await response.json();

**2. Stable Web Streams API**

The Web Streams API enables streaming data processing and is now stable in Node 24. Crucial for managing large data sets effectively — real-time data processing, downloads, and file uploads — without storing all the data in memory.

**3. ESM and CommonJS Interoperability**

The ESM/CommonJS boundary has been refined. The ESM CommonJS wrapper now exports module.exports by default, simplifying interoperability for hybrid module systems.

**4. Stricter Runtime Validation**

Many APIs now include improved argument and option validation:
- Buffer APIs now throw when attempting to write beyond their length.
- fs.symlink() and timers APIs enforce stricter type validation.
- Invalid inputs to fs.existsSync() now trigger runtime warnings.

**5. Deprecated and Removed APIs**

Node.js 24 removes several legacy APIs including deprecated utilities like util.is*() methods, fs.truncate() (with file descriptors), and tls.createSecurePair().

**6. Improved Web & global APIs**

Node 24 continues the "Node feels more like the browser" trend:
- New globals like CloseEvent, Float16Array, and URLPattern are available.
- The built-in fetch() implementation is stricter and no longer cooperates with third-party polyfills for things like Blob, FormData, and AbortController.

Result: code that targets modern Web APIs behaves more consistently across browser and Node, with fewer weird edge cases.`,},
  {id:44,date:"2025-11-23",author:"Victor Zhinzherov",tags:["OpenAI","ChatGPT","Collaboration"],emoji:"👥",
   title:"ChatGPT Group Chats Are Here: Up to 20 People + AI as a Teammate",
   summary:"Create a shared ChatGPT group chat with up to 20 people. ChatGPT joins with group conversation instincts — only jumps in when relevant. Useful for architecture reviews and requirement gathering.",
   body:`Starting today, you can open a group chat with ChatGPT inside, and it doesn't just respond — it understands the group dynamics and knows when to jump in (and when it's better to stay quiet). Pretty much like having a real teammate in the room.

**What is it?**

You can now open one shared chat with up to 20 people plus ChatGPT, planning, brainstorming, researching, or debating together in the same conversation. Think WhatsApp group + ChatGPT as an active teammate. You can invite anyone using a shared link.

**What you can do with it**

- Do system design or architecture reviews together
- Paste logs or stack traces; ChatGPT can help debug across everyone's messages
- Collect requirements from PM, designer, and engineers in one place and let ChatGPT draft the spec
- Run a mini design review: upload screenshots, code snippets, flows, and have ChatGPT summarize decisions
- Compare multiple approaches (e.g., event-driven vs polling, SQL vs NoSQL) with your team
- Work on code together: ChatGPT can suggest refactors while all team members discuss

**Smarter behavior**

ChatGPT has new "group conversation instincts":
- Joins only when needed
- Can react with emojis
- Can reference participants' profile photos
- Follows conversation flow instead of answering every message

**Privacy**

- Group chats are fully separate from your private chats
- Your personal ChatGPT memory is not used or shared
- You control invitations, participants, and notifications

**Availability**

Rolling out globally for Free, Go, Plus, and Pro users.`,
   link:"https://openai.com/index/group-chats-in-chatgpt/"},
  {id:45,date:"2025-11-20",author:"Tony Dolev",tags:["Google","IDE","Tools"],emoji:"🚀",
   title:"Google Antigravity: Time-Travel Debugging and Live Variable Peeking",
   summary:"Google's new experimental IDE features time-travel debugging (literally rewind your code), live variable peeking without pausing, cloud execution on demand, and deterministic reruns.",
   body:`Cool stuff in Google Antigravity — the New Google IDE:

- ⏪ Time-travel debugging (yes, literally rewind your code)
- 👀 Live variable peeking without stopping anything
- ☁️ Cloud execution on demand — no setup, no crying
- 🤝 Shared debugging sessions (pair programming but less awkward)
- 🧠 Deterministic reruns — bugs can't hide anymore

**Time-travel debugging**

This is the headline feature. Traditional debuggers only let you step forward through execution. Antigravity records program state at every step, so you can literally rewind to any point in time and inspect what was happening. No more trying to reproduce a flaky bug by guessing which inputs triggered it.

**Live variable peeking**

In traditional debuggers, you have to pause execution ("hit a breakpoint") to inspect variables. Antigravity lets you watch variables change in real-time as your program runs, without pausing anything. You see the full execution story, not just a snapshot.

**Deterministic reruns**

If your program produces a bug on one run but not another, Antigravity can record and replay the exact execution sequence that triggered it. The bug can't hide by being non-deterministic. When you replay, you get the exact same sequence of events every time.

Check it out at https://antigravity.google/`,
   link:"https://antigravity.google/"},
  {id:46,date:"2025-11-13",author:"Victor Zhinzherov",tags:["OpenAI","GPT-5.1","Model Release"],emoji:"🎭",
   title:"ChatGPT 5.1: Two Models, Eight Personality Presets, and Real-Time Tone Controls",
   summary:"GPT-5.1 Instant (fast default) and GPT-5.1 Thinking (deeper reasoning). Eight communication presets: Professional, Friendly, Candid, Efficient, Cynical, Quirky, Nerdy, Default.",
   body:`OpenAI has released ChatGPT 5.1, bringing two upgraded models — Instant and Thinking — plus a major overhaul in how the AI communicates. The focus this time is clarity, instruction-following, personalized tone, and more human-like interaction patterns.

**Two new models built for different tasks**

- GPT-5.1 Instant — the new fast default for everyday queries, warmer tone, better adherence to instructions.
- GPT-5.1 Thinking — slower, deeper reasoning with clearer explanations and less jargon.
- Adaptive reasoning: Both models now decide when to "think longer" before answering, improving accuracy without feeling sluggish.
- Better benchmarks: Improved performance on math, coding, and reasoning tests (AIME 2025, Codeforces) compared to GPT-5.

**New Personality Controls**

One of the biggest upgrades: eight built-in communication styles you can switch between instantly, even mid-conversation.

These change how ChatGPT responds, not what it knows — helping match different tasks like coding, documentation, or brainstorming:

- Professional — formal, structured, business-appropriate
- Friendly — warm, conversational, approachable
- Candid — direct, no sugar-coating
- Efficient — short, dense, no filler
- Cynical — skeptical tone with dry wit
- Quirky — creative, unexpected angles
- Nerdy — technical depth, references, enthusiasm
- Default — balanced, general-purpose

**Why It Matters for Engineers**

- More accurate debugging, refactoring, and multi-step code reasoning
- Clearer explanations from the Thinking model
- Faster iteration with the Instant model
- Real-time tone shifting — useful when switching between doc writing, Slack messages, and code reviews
- More predictable behavior across long tasks

**Availability & Rollout**

Rolling out now to paid ChatGPT subscribers, with free users following shortly. Instant = gpt-5.1-chat-latest in the API. Thinking = gpt-5.1 in the API.`,},
  {id:47,date:"2025-11-12",author:"Benji Amram",tags:["Google","Gemini","Documentation"],emoji:"📄",
   title:"Using Google File Search + Gemini to Auto-Generate Documentation Updates",
   summary:"A practical workflow: index release notes, current docs, and style guide via File Search → generate a machine-readable JSON patch list with citations → open a GitHub PR automatically.",
   body:`And this is an idea how this can be used to help auto generate doc updates.

Google's new File Search doesn't publish docs by itself, but it's great for drafting accurate, cited updates from release notes when you combine it with Gemini's generation + structured output and a CI step (e.g., a GitHub Action) to open PRs. File Search gives you managed RAG — ingest, chunk, embed, and retrieve your source-of-truth text — so the model can propose edits grounded in the release notes and existing docs.

**How it would help**

- Grounded proposals: The model pulls exact snippets from your release notes and current docs, reducing hallucinations and adding traceable citations.
- Deterministic change format: Ask Gemini to return a JSON object (or a unified diff) that conforms to a JSON Schema, so your pipeline can apply changes mechanically.
- PR automation: Use function calling / tool use to hit your repo or docs CMS API and open a branch + PR with the generated patch.

**A practical workflow**

1. Index sources with File Search — Store: (a) latest release notes, (b) current product docs, (c) your style guide.

2. Find impact surface — Query: "Which pages/sections are affected by Feature X?" Use the retrieved passages + file paths as context.

3. Generate changes (structured) — Prompt Gemini to output a machine-readable patch list with fields: doc_path, anchor, change_type, proposed_markdown, and citations.

4. Open a PR automatically — Via function calling (GitHub/GitLab/Docs CMS APIs) or the run-gemini-cli action to create a branch, apply patches, and open a PR with inline citations.

5. Human-in-the-loop — Require reviewer approval; run link checkers, doc lints, and style checks in CI before merge.

**Limits & gotchas**

- File Search won't decide policy or style — index your style guide and templates so the drafts match your voice.
- Some updates (images, complex diagrams, code samples) still need manual work.
- Keep it draft PRs, not auto-publish; ambiguous release notes should trigger a "needs PM/Eng confirmation" status.`,
   link:"https://ai.google.dev/gemini-api/docs/file-search"},
];

const ALL_POSTS = [...POSTS, ...POSTS_PART2];
const ALL_TAGS = [...new Set(ALL_POSTS.flatMap(p => p.tags))].sort();

export default function App() {
  const [isDark, setIsDark] = useState(true);
  const [search, setSearch] = useState("");
  const [activeTag, setActiveTag] = useState(null);
  const [selectedPost, setSelectedPost] = useState(null);
  const [showTagPanel, setShowTagPanel] = useState(false);

  const t = isDark ? DARK : LIGHT;

  const filtered = useMemo(() => {
    return ALL_POSTS.filter(p => {
      const ms = search.toLowerCase();
      const matchSearch = !search ||
        p.title.toLowerCase().includes(ms) ||
        p.summary.toLowerCase().includes(ms) ||
        p.author.toLowerCase().includes(ms) ||
        p.tags.some(tag => tag.toLowerCase().includes(ms));
      const matchTag = !activeTag || p.tags.includes(activeTag);
      return matchSearch && matchTag;
    });
  }, [search, activeTag]);

  return (
    <div style={{ minHeight:"100vh", background:t.bg, color:t.text, transition:"background 0.25s, color 0.25s" }}>
      <div style={{ padding:"32px 32px 0", maxWidth:"1200px", margin:"0 auto" }}>
        {/* Header */}
        <div style={{ display:"flex", alignItems:"flex-end", justifyContent:"space-between", marginBottom:"4px", flexWrap:"wrap", gap:"12px" }}>
          <div>
            <div style={{ fontSize:"11px", letterSpacing:"0.12em", color:t.accent, fontFamily:"monospace", textTransform:"uppercase", marginBottom:"6px" }}>
              #ai-nurture-tech-talks
            </div>
            <h1 style={{
              margin:0, fontSize:"clamp(24px, 4vw, 36px)", fontWeight:900,
              letterSpacing:"-0.03em", lineHeight:1.1,
              background: isDark ? t.titleGradient : "none",
              WebkitBackgroundClip: isDark ? "text" : undefined,
              WebkitTextFillColor: isDark ? "transparent" : undefined,
              color: isDark ? undefined : t.titleFill,
            }}>
              AI Intelligence Feed
            </h1>
          </div>
          <div style={{ display:"flex", alignItems:"center", gap:"16px" }}>
            <div style={{ fontSize:"12px", color:t.textFaint, fontFamily:"monospace", textAlign:"right" }}>
              <div style={{ color:t.signalGreen, fontWeight:700 }}>{ALL_POSTS.length} posts</div>
              <div>Nov 2025 → Jun 2026</div>
            </div>
            {/* Theme toggle */}
            <button
              onClick={() => setIsDark(!isDark)}
              title={isDark ? "Switch to light mode" : "Switch to dark mode"}
              style={{
                width:"52px", height:"28px", borderRadius:"14px",
                background: isDark ? "#3B82F6" : "#CBD5E1",
                border:"none", cursor:"pointer", position:"relative",
                transition:"background 0.25s", flexShrink:0,
                display:"flex", alignItems:"center",
              }}
            >
              <div style={{
                position:"absolute",
                left: isDark ? "26px" : "2px",
                width:"24px", height:"24px", borderRadius:"50%",
                background:"#fff",
                transition:"left 0.2s",
                display:"flex", alignItems:"center", justifyContent:"center",
                fontSize:"13px", boxShadow:"0 1px 4px rgba(0,0,0,0.2)",
              }}>
                {isDark ? "🌙" : "☀️"}
              </div>
            </button>
          </div>
        </div>

        {/* Search + Filter */}
        <div style={{ margin:"20px 0 16px", display:"flex", gap:"10px", flexWrap:"wrap" }}>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search posts, topics, authors..."
            style={{
              flex:1, minWidth:"200px", padding:"10px 16px",
              background:t.input, border:`1px solid ${t.inputBorder}`,
              borderRadius:"8px", color:t.text, fontSize:"13px",
              fontFamily:"monospace", outline:"none",
              transition:"background 0.2s, border-color 0.2s",
            }}
          />
          <button
            onClick={() => setShowTagPanel(!showTagPanel)}
            style={{
              padding:"10px 16px",
              background: showTagPanel ? t.accentBg : t.input,
              border: showTagPanel ? `1px solid ${t.accentBorder}` : `1px solid ${t.inputBorder}`,
              borderRadius:"8px", color: showTagPanel ? t.accent : t.textMuted,
              cursor:"pointer", fontSize:"12px", fontFamily:"monospace", transition:"all 0.15s",
            }}
          >
            {activeTag ? `Tag: ${activeTag} ×` : "🏷 Filter Tags"}
          </button>
          {(search || activeTag) && (
            <button
              onClick={() => { setSearch(""); setActiveTag(null); }}
              style={{
                padding:"10px 14px", background:t.clearBg,
                border:`1px solid ${t.clearBorder}`,
                borderRadius:"8px", color:t.clearText,
                cursor:"pointer", fontSize:"12px", fontFamily:"monospace",
              }}
            >
              Clear
            </button>
          )}
        </div>

        {/* Tag panel */}
        {showTagPanel && (
          <div style={{
            display:"flex", flexWrap:"wrap", gap:"6px", padding:"16px",
            background:t.surface, borderRadius:"8px", border:`1px solid ${t.border}`, marginBottom:"16px",
          }}>
            {ALL_TAGS.map(tag => (
              <TagBadge key={tag} tag={tag} t={t} isDark={isDark}
                selected={activeTag === tag}
                onClick={() => { setActiveTag(activeTag === tag ? null : tag); setShowTagPanel(false); }}
              />
            ))}
          </div>
        )}

        {/* Quick tag row */}
        {!showTagPanel && (
          <div style={{ display:"flex", gap:"6px", flexWrap:"wrap", marginBottom:"24px" }}>
            {ALL_TAGS.slice(0, 14).map(tag => (
              <TagBadge key={tag} tag={tag} t={t} isDark={isDark}
                selected={activeTag === tag}
                onClick={() => setActiveTag(activeTag === tag ? null : tag)}
              />
            ))}
          </div>
        )}

        {/* Results count */}
        <div style={{ fontSize:"11px", fontFamily:"monospace", color:t.textFaint, marginBottom:"16px" }}>
          {filtered.length === ALL_POSTS.length
            ? `Showing all ${ALL_POSTS.length} posts`
            : `${filtered.length} of ${ALL_POSTS.length} posts match`}
        </div>
      </div>

      {/* Grid */}
      <div style={{
        padding:"0 32px 48px", maxWidth:"1200px", margin:"0 auto",
        display:"grid", gridTemplateColumns:"repeat(auto-fill, minmax(320px, 1fr))", gap:"16px",
      }}>
        {filtered.map(post => (
          <PostCard key={post.id} post={post} t={t} isDark={isDark} onClick={() => setSelectedPost(post)} />
        ))}
        {filtered.length === 0 && (
          <div style={{ gridColumn:"1 / -1", textAlign:"center", padding:"60px 20px", color:t.textFaint, fontSize:"14px", fontFamily:"monospace" }}>
            No posts match that filter. Try clearing the search.
          </div>
        )}
      </div>

      {/* Footer */}
      <div style={{
        padding:"20px 32px", borderTop:`1px solid ${t.footerBorder}`,
        maxWidth:"1200px", margin:"0 auto",
        display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:"8px",
      }}>
        <span style={{ fontSize:"11px", color:t.textFaint, fontFamily:"monospace" }}>
          #ai-nurture-tech-talks · Apartment List · Nov 2025–Jun 2026
        </span>
        <div style={{ display:"flex", gap:"4px", alignItems:"center" }}>
          <span style={{ fontSize:"11px", color:t.textFaint, fontFamily:"monospace" }}>Signal: </span>
          <SignalBars bars={4} color={t.signalGreen} t={t} />
        </div>
      </div>

      {selectedPost && (
        <PostModal post={selectedPost} onClose={() => setSelectedPost(null)} t={t} isDark={isDark} />
      )}
    </div>
  );
}
