/* @ds-bundle: {"format":3,"namespace":"ApartmentListDesignSystem_9ce450","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"FilterChip","sourcePath":"components/core/FilterChip.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Input","sourcePath":"components/core/Input.jsx"},{"name":"SegmentedControl","sourcePath":"components/core/SegmentedControl.jsx"},{"name":"ListingCard","sourcePath":"components/product/ListingCard.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"8bf22956fede","components/core/Badge.jsx":"311291791784","components/core/Button.jsx":"df32f7127905","components/core/Card.jsx":"ea5682ac6d53","components/core/FilterChip.jsx":"a2a135e4d81f","components/core/IconButton.jsx":"b0c58018eb3a","components/core/Input.jsx":"23433e17ec1f","components/core/SegmentedControl.jsx":"b83c4b13da3e","components/product/ListingCard.jsx":"5b862cbfd876","ui_kits/marketing_site/Sections.jsx":"c56b6c2cdb30","ui_kits/mobile_app/Icons.jsx":"8f143b64a8bb","ui_kits/mobile_app/Matchmaker.jsx":"803783e76d58","ui_kits/mobile_app/Screens.jsx":"d3f4de0fafec","ui_kits/mobile_app/data.js":"7c92fdbbdf65","ui_kits/mobile_app/ios-frame.jsx":"be3343be4b51"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ApartmentListDesignSystem_9ce450 = window.ApartmentListDesignSystem_9ce450 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Circular avatar with image or initials fallback.
 */
function Avatar({
  src,
  name = "",
  size = 40,
  style = {},
  ...rest
}) {
  const initials = name.split(" ").map(p => p[0]).filter(Boolean).slice(0, 2).join("").toUpperCase();
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      width: size,
      height: size,
      borderRadius: "var(--radius-circle)",
      background: "var(--al-purple-100)",
      color: "var(--color-brand-strong)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      fontFamily: "var(--font-sans)",
      fontWeight: 600,
      fontSize: size * 0.4,
      flex: "none",
      ...style
    }
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }) : initials || "?");
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Small status / category label. Includes Apartment List match types.
 */
function Badge({
  children,
  variant = "neutral",
  size = "md",
  style = {},
  ...rest
}) {
  const variants = {
    neutral: {
      background: "var(--al-gray-100)",
      color: "var(--text-secondary)"
    },
    brand: {
      background: "var(--al-purple-100)",
      color: "var(--color-brand-strong)"
    },
    perfect: {
      background: "var(--color-brand)",
      color: "#fff"
    },
    flex: {
      background: "var(--al-orange)",
      color: "#fff"
    },
    success: {
      background: "#E2F3EA",
      color: "var(--state-success)"
    },
    warning: {
      background: "#FFE9D6",
      color: "#9A4A0E"
    },
    error: {
      background: "#FFE0E5",
      color: "var(--state-error)"
    },
    outline: {
      background: "transparent",
      color: "var(--text-secondary)",
      border: "1px solid var(--border-default)"
    }
  };
  const sizes = {
    sm: {
      fontSize: 11,
      padding: "3px 8px"
    },
    md: {
      fontSize: 12,
      padding: "4px 10px"
    },
    lg: {
      fontSize: 13,
      padding: "6px 12px"
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 5,
      fontFamily: "var(--font-sans)",
      fontWeight: 600,
      letterSpacing: "0.01em",
      borderRadius: "var(--radius-pill)",
      lineHeight: 1.2,
      whiteSpace: "nowrap",
      ...sizes[size],
      ...variants[variant],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Apartment List primary action component.
 * Pill-shaped, Haffer SemiBold, soft brand shadow on primary.
 */
function Button({
  children,
  variant = "primary",
  size = "md",
  fullWidth = false,
  disabled = false,
  iconLeft = null,
  iconRight = null,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: "8px 16px",
      fontSize: 14,
      height: 36,
      gap: 6
    },
    md: {
      padding: "12px 24px",
      fontSize: 16,
      height: 48,
      gap: 8
    },
    lg: {
      padding: "16px 32px",
      fontSize: 18,
      height: 56,
      gap: 10
    }
  };
  const s = sizes[size] || sizes.md;
  const base = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: s.gap,
    height: s.height,
    padding: s.padding,
    fontSize: s.fontSize,
    fontFamily: "var(--font-sans)",
    fontWeight: 600,
    lineHeight: 1,
    borderRadius: "var(--radius-pill)",
    border: "1.5px solid transparent",
    cursor: disabled ? "not-allowed" : "pointer",
    width: fullWidth ? "100%" : "auto",
    transition: "background var(--dur-base) var(--ease-standard), transform var(--dur-fast) var(--ease-standard), box-shadow var(--dur-base) var(--ease-standard), color var(--dur-base) var(--ease-standard)",
    opacity: disabled ? 0.45 : 1,
    whiteSpace: "nowrap"
  };
  const variants = {
    primary: {
      background: "var(--color-brand)",
      color: "var(--text-on-brand)",
      boxShadow: "var(--shadow-brand)"
    },
    secondary: {
      background: "var(--surface-card)",
      color: "var(--color-brand-strong)",
      borderColor: "var(--border-default)"
    },
    ghost: {
      background: "transparent",
      color: "var(--color-brand-strong)"
    },
    inverse: {
      background: "var(--surface-card)",
      color: "var(--color-brand-strong)"
    },
    danger: {
      background: "var(--state-error)",
      color: "#fff"
    }
  };
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const hoverStyle = hover && !disabled ? {
    primary: {
      background: "var(--color-brand-strong)"
    },
    secondary: {
      background: "var(--color-brand-tint)",
      borderColor: "var(--color-brand)"
    },
    ghost: {
      background: "var(--color-brand-tint)"
    },
    inverse: {
      background: "var(--al-oat-100)"
    },
    danger: {
      filter: "brightness(0.92)"
    }
  }[variant] : {};
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false),
    style: {
      ...base,
      ...variants[variant],
      ...hoverStyle,
      transform: active && !disabled ? "scale(0.98)" : "scale(1)",
      ...style
    }
  }, rest), iconLeft, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Surface container with the Apartment List card treatment:
 * white surface on the oat canvas, soft shadow, generous radius.
 */
function Card({
  children,
  padding = 20,
  interactive = false,
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", _extends({
    onMouseEnter: () => interactive && setHover(true),
    onMouseLeave: () => interactive && setHover(false),
    style: {
      background: "var(--surface-card)",
      borderRadius: "var(--radius-lg)",
      boxShadow: hover ? "var(--shadow-md)" : "var(--shadow-sm)",
      border: "1px solid var(--border-subtle)",
      padding,
      transition: "box-shadow var(--dur-base) var(--ease-standard), transform var(--dur-base) var(--ease-standard)",
      transform: hover ? "translateY(-2px)" : "none",
      cursor: interactive ? "pointer" : "default",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/FilterChip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Selectable filter chip — used in search filters and quiz answers.
 */
function FilterChip({
  children,
  selected = false,
  iconLeft = null,
  onClick,
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      fontWeight: 600,
      padding: "9px 16px",
      borderRadius: "var(--radius-pill)",
      cursor: "pointer",
      transition: "all var(--dur-base) var(--ease-standard)",
      background: selected ? "var(--color-brand)" : hover ? "var(--color-brand-tint)" : "var(--surface-card)",
      color: selected ? "#fff" : "var(--color-brand-strong)",
      border: `1.5px solid ${selected ? "var(--color-brand)" : "var(--border-default)"}`,
      ...style
    }
  }, rest), iconLeft, children);
}
Object.assign(__ds_scope, { FilterChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/FilterChip.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Circular icon-only button (favorites, close, map controls).
 */
function IconButton({
  children,
  variant = "soft",
  size = 44,
  label,
  onClick,
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const variants = {
    soft: {
      background: hover ? "var(--al-gray-100)" : "var(--surface-card)",
      color: "var(--text-heading)",
      border: "1px solid var(--border-subtle)"
    },
    solid: {
      background: hover ? "var(--color-brand-strong)" : "var(--color-brand)",
      color: "#fff",
      border: "none"
    },
    ghost: {
      background: hover ? "var(--color-brand-tint)" : "transparent",
      color: "var(--text-heading)",
      border: "none"
    },
    glass: {
      background: hover ? "#fff" : "rgba(255,255,255,0.9)",
      color: "var(--color-brand-strong)",
      border: "none",
      backdropFilter: "blur(6px)"
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: size,
      height: size,
      borderRadius: "var(--radius-circle)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      cursor: "pointer",
      boxShadow: variant === "soft" || variant === "glass" ? "var(--shadow-sm)" : "none",
      transition: "all var(--dur-base) var(--ease-standard)",
      ...variants[variant],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Labelled text input with the Apartment List field styling.
 */
function Input({
  label,
  hint,
  error,
  iconLeft = null,
  fullWidth = true,
  style = {},
  id,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const fieldId = id || React.useId();
  const borderColor = error ? "var(--state-error)" : focus ? "var(--color-brand)" : "var(--border-default)";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: fullWidth ? "100%" : "auto",
      fontFamily: "var(--font-sans)"
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      display: "block",
      fontSize: 14,
      fontWeight: 600,
      color: "var(--text-heading)",
      marginBottom: 6
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      background: "var(--surface-card)",
      border: `1.5px solid ${borderColor}`,
      borderRadius: "var(--radius-md)",
      padding: "0 14px",
      height: 48,
      boxShadow: focus ? "0 0 0 4px rgba(195,132,240,0.25)" : "none",
      transition: "border var(--dur-base) var(--ease-standard), box-shadow var(--dur-base) var(--ease-standard)"
    }
  }, iconLeft && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      color: "var(--text-muted)"
    }
  }, iconLeft), /*#__PURE__*/React.createElement("input", _extends({
    id: fieldId,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      border: "none",
      outline: "none",
      background: "transparent",
      fontFamily: "var(--font-sans)",
      fontSize: 16,
      color: "var(--text-primary)",
      height: "100%",
      ...style
    }
  }, rest))), (hint || error) && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      marginTop: 6,
      color: error ? "var(--state-error)" : "var(--text-muted)"
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Input.jsx", error: String((e && e.message) || e) }); }

// components/core/SegmentedControl.jsx
try { (() => {
/**
 * Segmented control — used for Perfect / Flex match tabs and view toggles.
 */
function SegmentedControl({
  options = [],
  value,
  onChange,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "inline-flex",
      background: "var(--al-gray-100)",
      borderRadius: "var(--radius-pill)",
      padding: 4,
      gap: 2,
      ...style
    }
  }, options.map(opt => {
    const val = typeof opt === "string" ? opt : opt.value;
    const label = typeof opt === "string" ? opt : opt.label;
    const active = val === value;
    return /*#__PURE__*/React.createElement("button", {
      key: val,
      type: "button",
      onClick: () => onChange && onChange(val),
      style: {
        border: "none",
        cursor: "pointer",
        fontFamily: "var(--font-sans)",
        fontSize: 14,
        fontWeight: 600,
        padding: "8px 18px",
        borderRadius: "var(--radius-pill)",
        background: active ? "var(--surface-card)" : "transparent",
        color: active ? "var(--color-brand-strong)" : "var(--text-secondary)",
        boxShadow: active ? "var(--shadow-xs)" : "none",
        transition: "all var(--dur-base) var(--ease-standard)"
      }
    }, label);
  }));
}
Object.assign(__ds_scope, { SegmentedControl });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SegmentedControl.jsx", error: String((e && e.message) || e) }); }

// components/product/ListingCard.jsx
try { (() => {
/**
 * Apartment List property listing card — the core repeating unit of the
 * Matches feed, map drawer, and shortlist. Composes Badge + IconButton.
 */
function ListingCard({
  image,
  name,
  address,
  price,
  period = "/mo",
  beds,
  baths,
  sqft,
  match,
  // "perfect" | "flex" | null
  rating,
  saved = false,
  onSave,
  onClick,
  width = 320,
  style = {}
}) {
  const matchLabel = match === "perfect" ? "Perfect Match" : match === "flex" ? "Flex Match" : null;
  const specs = [beds != null && `${beds} bd`, baths != null && `${baths} ba`, sqft != null && `${sqft.toLocaleString()} sqft`].filter(Boolean);
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width,
      background: "var(--surface-card)",
      borderRadius: "var(--radius-lg)",
      overflow: "hidden",
      border: "1px solid var(--border-subtle)",
      boxShadow: hover ? "var(--shadow-md)" : "var(--shadow-sm)",
      transform: hover ? "translateY(-2px)" : "none",
      transition: "all var(--dur-base) var(--ease-standard)",
      cursor: onClick ? "pointer" : "default",
      fontFamily: "var(--font-sans)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      aspectRatio: "4 / 3",
      background: "var(--al-gray-100)"
    }
  }, image && /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: name,
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover",
      display: "block"
    }
  }), matchLabel && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 12,
      left: 12
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    variant: match,
    size: "md"
  }, matchLabel)), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 8,
      right: 8
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    variant: "glass",
    size: 40,
    label: saved ? "Saved" : "Save",
    onClick: e => {
      e.stopPropagation();
      onSave && onSave();
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "20",
    height: "20",
    viewBox: "0 0 24 24",
    fill: saved ? "var(--color-brand)" : "none",
    stroke: saved ? "var(--color-brand)" : "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.29 1.51 4.04 3 5.5l7 7Z"
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "14px 16px 16px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      justifyContent: "space-between",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 20,
      fontWeight: 700,
      color: "var(--text-heading)",
      letterSpacing: "-0.01em"
    }
  }, price, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text-secondary)"
    }
  }, period)), rating != null && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 3,
      fontSize: 13,
      fontWeight: 600,
      color: "var(--text-secondary)"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "var(--al-orange)",
    stroke: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M12 2l2.9 6.3 6.9.7-5.2 4.6 1.5 6.8L12 17.8 5.9 20.4l1.5-6.8L2.2 9l6.9-.7z"
  })), rating)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15,
      fontWeight: 600,
      color: "var(--text-heading)",
      marginTop: 4
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text-secondary)",
      marginTop: 2
    }
  }, address), specs.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text-secondary)",
      marginTop: 8,
      display: "flex",
      gap: 6
    }
  }, specs.map((s, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--border-default)"
    }
  }, "\xB7"), /*#__PURE__*/React.createElement("span", null, s))))));
}
Object.assign(__ds_scope, { ListingCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/product/ListingCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing_site/Sections.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// Apartment List — marketing site sections. Composes DS primitives from the bundle.
const MS = window.ApartmentListDesignSystem_9ce450;
const {
  Button: MB,
  Badge: MBadge,
  Input: MInput,
  ListingCard: MLC,
  FilterChip: MFC
} = MS;
const LOGO = "../../assets/logos/apartment-list-logo-large.png";
const HOUSE_WHITE = "../../assets/logos/house-mark-white.png";
function Header() {
  const nav = ["How it works", "Cities", "Renters", "Property managers"];
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 30,
      background: "rgba(245,242,237,0.85)",
      backdropFilter: "blur(10px)",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto",
      height: 72,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "0 32px"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: LOGO,
    alt: "Apartment List",
    style: {
      height: 26
    }
  }), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      gap: 30
    }
  }, nav.map(n => /*#__PURE__*/React.createElement("a", {
    key: n,
    href: "#",
    style: {
      fontSize: 15,
      fontWeight: 500,
      color: "var(--text-heading)",
      textDecoration: "none"
    }
  }, n))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      fontSize: 15,
      fontWeight: 600,
      color: "var(--color-brand-strong)",
      textDecoration: "none"
    }
  }, "Log in"), /*#__PURE__*/React.createElement(MB, {
    size: "sm"
  }, "Get started"))));
}
function Hero() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 1200,
      margin: "0 auto",
      padding: "72px 32px 56px",
      display: "grid",
      gridTemplateColumns: "1.05fr 0.95fr",
      gap: 56,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "al-eyebrow",
    style: {
      marginBottom: 16
    }
  }, "The rental matchmaker"), /*#__PURE__*/React.createElement("h1", {
    className: "al-display",
    style: {
      fontSize: 84,
      color: "var(--text-heading)",
      margin: 0
    }
  }, "find your ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--color-brand)"
    }
  }, "perfect"), " apartment match"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 19,
      lineHeight: 1.55,
      color: "var(--text-secondary)",
      marginTop: 22,
      maxWidth: 480
    }
  }, "Tell us what you want in your next home, and we'll instantly recommend premium apartments curated just for you \u2014 saving you 50+ hours of searching."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      marginTop: 30,
      maxWidth: 480
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(MInput, {
    placeholder: "Enter a city or neighborhood",
    iconLeft: /*#__PURE__*/React.createElement(window.MSPin, null)
  })), /*#__PURE__*/React.createElement(MB, {
    size: "md"
  }, "Get matched")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 26,
      marginTop: 28
    }
  }, [["6M+", "apartments"], ["50", "states"], ["5 min", "quiz"]].map(([n, l]) => /*#__PURE__*/React.createElement("div", {
    key: l
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 32,
      fontWeight: 600,
      color: "var(--color-brand-strong)",
      lineHeight: 1
    }
  }, n), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text-secondary)",
      marginTop: 2
    }
  }, l))))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=900&q=80",
    alt: "Bright modern apartment",
    style: {
      width: "100%",
      aspectRatio: "4/5",
      objectFit: "cover",
      borderRadius: "var(--radius-2xl)",
      boxShadow: "var(--shadow-lg)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      bottom: 22,
      left: -28,
      background: "var(--surface-card)",
      borderRadius: "var(--radius-lg)",
      boxShadow: "var(--shadow-lg)",
      padding: "14px 18px",
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 44,
      height: 44,
      borderRadius: 12,
      background: "var(--color-brand)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: HOUSE_WHITE,
    alt: "",
    style: {
      width: 26
    }
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(MBadge, {
    variant: "perfect",
    size: "sm"
  }, "Perfect Match"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      color: "var(--text-heading)",
      marginTop: 4
    }
  }, "The Eliot \xB7 $2,450/mo")))));
}
function HowItWorks() {
  const steps = [["Take the quiz", "Answer a few questions about budget, location, and must-have amenities."], ["Get your matches", "We instantly sort listings into Perfect Matches and Flex Matches."], ["Tour & rent", "Book tours, track price drops, and contact properties — all in one place."]];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--surface-card)",
      borderTop: "1px solid var(--border-subtle)",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto",
      padding: "72px 32px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "al-eyebrow",
    style: {
      textAlign: "center"
    }
  }, "How it works"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 40,
      fontWeight: 700,
      textAlign: "center",
      marginTop: 12,
      letterSpacing: "-0.02em"
    }
  }, "Apartment hunting, minus the swamp"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3,1fr)",
      gap: 28,
      marginTop: 48
    }
  }, steps.map(([t, d], i) => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: "50%",
      background: "var(--al-purple-100)",
      color: "var(--color-brand)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 22,
      fontWeight: 700,
      margin: "0 auto",
      fontFamily: "var(--font-sans)"
    }
  }, i + 1), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 21,
      fontWeight: 700,
      marginTop: 18
    }
  }, t), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      color: "var(--text-secondary)",
      marginTop: 8,
      lineHeight: 1.55
    }
  }, d))))));
}
function MatchShowcase() {
  const items = window.AL_LISTINGS;
  return /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 1200,
      margin: "0 auto",
      padding: "72px 32px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-end",
      marginBottom: 32,
      flexWrap: "wrap",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "al-eyebrow"
  }, "Curated for you"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 36,
      fontWeight: 700,
      marginTop: 10,
      letterSpacing: "-0.02em"
    }
  }, "Premium matches in Seattle")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(MFC, {
    selected: true
  }, "Perfect Matches"), /*#__PURE__*/React.createElement(MFC, null, "Flex Matches"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4,1fr)",
      gap: 22
    }
  }, items.map(l => /*#__PURE__*/React.createElement(MLC, _extends({
    key: l.id,
    width: "100%"
  }, l)))));
}
function CTABand() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--color-brand)",
      color: "#fff",
      position: "relative",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: HOUSE_WHITE,
    alt: "",
    style: {
      position: "absolute",
      right: -40,
      top: -30,
      width: 320,
      opacity: 0.12
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto",
      padding: "72px 32px",
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("h2", {
    className: "al-display",
    style: {
      fontSize: 64,
      margin: 0,
      maxWidth: 720
    }
  }, "your next home is one quiz away"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 18,
      opacity: 0.9,
      marginTop: 16,
      maxWidth: 560
    }
  }, "Join millions of renters who found their match the personalized way."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 28
    }
  }, /*#__PURE__*/React.createElement(MB, {
    variant: "inverse",
    size: "lg"
  }, "Start the Rental Matchmaker"))));
}
function Footer() {
  const cols = {
    Renters: ["Search apartments", "How it works", "Renter guide", "Cities"],
    Company: ["About", "Careers", "Press", "Contact"],
    Resources: ["Help center", "Blog", "Sitemap", "Accessibility"]
  };
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: "var(--surface-inverse)",
      color: "rgba(255,255,255,0.85)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto",
      padding: "56px 32px 40px",
      display: "grid",
      gridTemplateColumns: "1.4fr repeat(3,1fr)",
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("img", {
    src: HOUSE_WHITE,
    alt: "Apartment List",
    style: {
      width: 40
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      marginTop: 16,
      opacity: 0.75,
      maxWidth: 240,
      lineHeight: 1.55
    }
  }, "The most personalized way to find your next apartment.")), Object.entries(cols).map(([h, links]) => /*#__PURE__*/React.createElement("div", {
    key: h
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 700,
      color: "#fff",
      letterSpacing: "0.04em",
      textTransform: "uppercase"
    }
  }, h), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10,
      marginTop: 16
    }
  }, links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#",
    style: {
      fontSize: 14,
      color: "rgba(255,255,255,0.8)",
      textDecoration: "none"
    }
  }, l)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "1px solid rgba(255,255,255,0.15)",
      padding: "20px 32px",
      maxWidth: 1200,
      margin: "0 auto",
      fontSize: 13,
      opacity: 0.6
    }
  }, "\xA9 2026 Apartment List, Inc. All rights reserved."));
}

// tiny pin icon for the hero input
window.MSPin = p => /*#__PURE__*/React.createElement("svg", {
  width: "18",
  height: "18",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, /*#__PURE__*/React.createElement("path", {
  d: "M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "10",
  r: "3"
}));
Object.assign(window, {
  ALHeader: Header,
  ALHero: Hero,
  ALHowItWorks: HowItWorks,
  ALMatchShowcase: MatchShowcase,
  ALCTABand: CTABand,
  ALFooter: Footer
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing_site/Sections.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile_app/Icons.jsx
try { (() => {
// Lucide-style inline icons (2px stroke, round caps) — matches the DS iconography spec.
// Exported to window for use across the mobile app kit.
function Icon({
  children,
  size = 24,
  fill = "none",
  stroke = "currentColor",
  sw = 2,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: fill,
    stroke: stroke,
    strokeWidth: sw,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: style
  }, children);
}
const IHeart = p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("path", {
  d: "M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.29 1.51 4.04 3 5.5l7 7Z"
}));
const IMapPin = p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("path", {
  d: "M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "10",
  r: "3"
}));
const ISearch = p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("circle", {
  cx: "11",
  cy: "11",
  r: "7"
}), /*#__PURE__*/React.createElement("path", {
  d: "m21 21-4.3-4.3"
}));
const IStar = p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("path", {
  d: "M12 2l2.9 6.3 6.9.7-5.2 4.6 1.5 6.8L12 17.8 5.9 20.4l1.5-6.8L2.2 9l6.9-.7z"
}));
const IBed = p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("path", {
  d: "M2 8v12M2 14h20M22 20V12a2 2 0 0 0-2-2H6a4 4 0 0 0-4 4"
}));
const IBath = p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("path", {
  d: "M4 12V5a2 2 0 0 1 2-2 2 2 0 0 1 2 2M2 12h20v3a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4Z"
}), /*#__PURE__*/React.createElement("path", {
  d: "M5 19l-1 2M20 19l1 2"
}));
const IHome = p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("path", {
  d: "M3 10.5 12 3l9 7.5"
}), /*#__PURE__*/React.createElement("path", {
  d: "M5 9.5V20h14V9.5"
}));
const IUser = p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "8",
  r: "4"
}), /*#__PURE__*/React.createElement("path", {
  d: "M4 21a8 8 0 0 1 16 0"
}));
const ISliders = p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("path", {
  d: "M4 6h11M19 6h1M4 12h5M13 12h7M4 18h9M17 18h3"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "17",
  cy: "6",
  r: "2"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "11",
  cy: "12",
  r: "2"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "15",
  cy: "18",
  r: "2"
}));
const IChevronLeft = p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("path", {
  d: "m15 18-6-6 6-6"
}));
const IChevronRight = p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("path", {
  d: "m9 18 6-6-6-6"
}));
const IShare = p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("circle", {
  cx: "18",
  cy: "5",
  r: "3"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "6",
  cy: "12",
  r: "3"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "18",
  cy: "19",
  r: "3"
}), /*#__PURE__*/React.createElement("path", {
  d: "m8.6 13.5 6.8 4M15.4 6.5l-6.8 4"
}));
const ICheck = p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("path", {
  d: "M20 6 9 17l-5-5"
}));
const IX = p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("path", {
  d: "M18 6 6 18M6 6l12 12"
}));
const ICalendar = p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("rect", {
  x: "3",
  y: "4",
  width: "18",
  height: "18",
  rx: "2"
}), /*#__PURE__*/React.createElement("path", {
  d: "M16 2v4M8 2v4M3 10h18"
}));
const ISparkle = p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("path", {
  d: "M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"
}));
const IList = p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("path", {
  d: "M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"
}));
const IMap = p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("path", {
  d: "M9 4 3 6v14l6-2 6 2 6-2V4l-6 2-6-2Z"
}), /*#__PURE__*/React.createElement("path", {
  d: "M9 4v14M15 6v14"
}));
const IPaw = p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("circle", {
  cx: "7",
  cy: "9",
  r: "1.6"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "7",
  r: "1.6"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "17",
  cy: "9",
  r: "1.6"
}), /*#__PURE__*/React.createElement("path", {
  d: "M12 12c-2.5 0-4.5 2-4.5 4 0 1.4 1.1 2.3 2.4 2.3.9 0 1.3-.4 2.1-.4s1.2.4 2.1.4c1.3 0 2.4-.9 2.4-2.3 0-2-2-4-4.5-4Z"
}));
Object.assign(window, {
  ALIcon: Icon,
  IHeart,
  IMapPin,
  ISearch,
  IStar,
  IBed,
  IBath,
  IHome,
  IUser,
  ISliders,
  IChevronLeft,
  IChevronRight,
  IShare,
  ICheck,
  IX,
  ICalendar,
  ISparkle,
  IList,
  IMap,
  IPaw
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile_app/Icons.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile_app/Matchmaker.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// Apartment List — Rental Matchmaker quiz + secondary screens.
const DS2 = window.ApartmentListDesignSystem_9ce450;
const {
  Button: B2,
  FilterChip: FC2,
  Input: IN2,
  ListingCard: LC2,
  SegmentedControl: SC2,
  IconButton: IB2
} = DS2;

// ── Matchmaker quiz ──────────────────────────────────────────
function MatchmakerScreen({
  onComplete
}) {
  const [step, setStep] = React.useState(0);
  const [answers, setAnswers] = React.useState({
    type: "Apartment",
    beds: "1 bed",
    amenities: {},
    budget: 2500
  });
  const steps = [{
    q: "What kind of place?",
    sub: "Tell us what you're looking for and we'll match you instantly.",
    body: /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexWrap: "wrap",
        gap: 10
      }
    }, ["Apartment", "Condo", "House", "Townhome"].map(t => /*#__PURE__*/React.createElement(FC2, {
      key: t,
      selected: answers.type === t,
      onClick: () => setAnswers({
        ...answers,
        type: t
      })
    }, t)))
  }, {
    q: "How much space?",
    sub: "Pick the layout that fits your life.",
    body: /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexWrap: "wrap",
        gap: 10
      }
    }, ["Studio", "1 bed", "2 beds", "3+ beds"].map(t => /*#__PURE__*/React.createElement(FC2, {
      key: t,
      selected: answers.beds === t,
      onClick: () => setAnswers({
        ...answers,
        beds: t
      })
    }, t)))
  }, {
    q: "Must-have amenities?",
    sub: "Choose all that matter — we'll prioritize them.",
    body: /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexWrap: "wrap",
        gap: 10
      }
    }, ["Pet friendly", "In-unit laundry", "Parking", "Gym", "Dishwasher", "Balcony", "Pool", "Rooftop"].map(t => /*#__PURE__*/React.createElement(FC2, {
      key: t,
      selected: !!answers.amenities[t],
      onClick: () => setAnswers({
        ...answers,
        amenities: {
          ...answers.amenities,
          [t]: !answers.amenities[t]
        }
      })
    }, t)))
  }, {
    q: "What's your budget?",
    sub: "We'll only show places you can actually afford.",
    body: /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "var(--font-display)",
        fontWeight: 600,
        fontSize: 56,
        color: "var(--color-brand)",
        lineHeight: 1
      }
    }, "$", answers.budget.toLocaleString(), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 18,
        color: "var(--text-secondary)",
        fontFamily: "var(--font-sans)",
        fontWeight: 500
      }
    }, "/mo")), /*#__PURE__*/React.createElement("input", {
      type: "range",
      min: "800",
      max: "5000",
      step: "50",
      value: answers.budget,
      onChange: e => setAnswers({
        ...answers,
        budget: +e.target.value
      }),
      style: {
        width: "100%",
        marginTop: 24,
        accentColor: "var(--color-brand)"
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        color: "var(--text-muted)",
        fontSize: 13,
        marginTop: 6
      }
    }, /*#__PURE__*/React.createElement("span", null, "$800"), /*#__PURE__*/React.createElement("span", null, "$5,000+")))
  }];
  const cur = steps[step];
  const last = step === steps.length - 1;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: "100%",
      display: "flex",
      flexDirection: "column",
      background: "var(--surface-card)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "10px 20px 0",
      display: "flex",
      gap: 6
    }
  }, steps.map((_, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      height: 5,
      borderRadius: 999,
      background: i <= step ? "var(--color-brand)" : "var(--al-gray-200)",
      transition: "background .3s"
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: "auto",
      padding: "28px 24px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      letterSpacing: "0.06em",
      textTransform: "uppercase",
      color: "var(--color-brand)"
    }
  }, "Rental Matchmaker"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 30,
      fontWeight: 700,
      color: "var(--text-heading)",
      letterSpacing: "-0.02em",
      marginTop: 8
    }
  }, cur.q), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      color: "var(--text-secondary)",
      marginTop: 8,
      marginBottom: 26
    }
  }, cur.sub), cur.body), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      padding: "14px 20px 28px",
      borderTop: "1px solid var(--border-subtle)"
    }
  }, step > 0 && /*#__PURE__*/React.createElement(B2, {
    variant: "secondary",
    onClick: () => setStep(step - 1)
  }, "Back"), /*#__PURE__*/React.createElement(B2, {
    variant: "primary",
    fullWidth: true,
    onClick: () => last ? onComplete() : setStep(step + 1)
  }, last ? "See my matches" : "Continue")));
}

// ── Shortlist ────────────────────────────────────────────────
function SavedScreen({
  saved,
  onOpen,
  onSave
}) {
  const list = window.AL_LISTINGS.filter(l => saved[l.id]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: "100%",
      display: "flex",
      flexDirection: "column",
      background: "var(--surface-page)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "8px 20px 14px",
      background: "var(--surface-card)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 24,
      fontWeight: 700,
      color: "var(--text-heading)"
    }
  }, "Your Shortlist"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text-secondary)",
      marginTop: 2
    }
  }, list.length, " saved ", list.length === 1 ? "home" : "homes")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: "auto",
      padding: "16px 20px 24px",
      display: "flex",
      flexDirection: "column",
      gap: 18
    }
  }, list.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      marginTop: 80,
      color: "var(--text-muted)"
    }
  }, /*#__PURE__*/React.createElement(window.IHeart, {
    size: 40,
    stroke: "var(--al-gray-300)"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 600,
      color: "var(--text-secondary)",
      marginTop: 12
    }
  }, "No saved homes yet"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      marginTop: 4
    }
  }, "Tap the heart on a match to save it here.")) : list.map(l => /*#__PURE__*/React.createElement(LC2, _extends({
    key: l.id,
    width: "100%"
  }, l, {
    saved: true,
    onSave: () => onSave(l.id),
    onClick: () => onOpen(l.id)
  })))));
}

// ── Map (static, brand-styled placeholder) ──────────────────
function MapScreen({
  onOpen
}) {
  const pins = [{
    id: "eliot",
    top: "32%",
    left: "40%",
    price: "$2.4k"
  }, {
    id: "marlowe",
    top: "55%",
    left: "62%",
    price: "$1.9k"
  }, {
    id: "harbor",
    top: "44%",
    left: "24%",
    price: "$3.1k"
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: "100%",
      position: "relative",
      background: "linear-gradient(135deg,#ECEAE6,#F5F2ED)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      backgroundImage: "linear-gradient(rgba(0,0,0,0.04) 1px,transparent 1px),linear-gradient(90deg,rgba(0,0,0,0.04) 1px,transparent 1px)",
      backgroundSize: "44px 44px"
    }
  }), pins.map(p => /*#__PURE__*/React.createElement("button", {
    key: p.id,
    onClick: () => onOpen(p.id),
    style: {
      position: "absolute",
      top: p.top,
      left: p.left,
      transform: "translate(-50%,-50%)",
      border: "none",
      cursor: "pointer",
      background: "var(--color-brand)",
      color: "#fff",
      fontWeight: 700,
      fontSize: 13,
      padding: "8px 12px",
      borderRadius: 999,
      boxShadow: "var(--shadow-brand)",
      fontFamily: "var(--font-sans)"
    }
  }, p.price)), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 14,
      left: 16,
      right: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-card)",
      borderRadius: "var(--radius-pill)",
      boxShadow: "var(--shadow-md)",
      padding: "12px 18px",
      display: "flex",
      alignItems: "center",
      gap: 10,
      color: "var(--text-secondary)"
    }
  }, /*#__PURE__*/React.createElement(window.ISearch, {
    size: 18
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15
    }
  }, "Seattle, WA"))));
}
Object.assign(window, {
  MatchmakerScreen,
  SavedScreen,
  MapScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile_app/Matchmaker.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile_app/Screens.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// Apartment List — mobile app screens. Composes DS primitives from the bundle.
const DS = window.ApartmentListDesignSystem_9ce450;
const {
  Button,
  Badge,
  FilterChip,
  SegmentedControl,
  IconButton,
  ListingCard,
  Avatar,
  Input
} = DS;

// ── Bottom tab bar ───────────────────────────────────────────
function BottomNav({
  active,
  onChange
}) {
  const tabs = [{
    id: "matches",
    label: "Matches",
    icon: window.IHome
  }, {
    id: "map",
    label: "Map",
    icon: window.IMap
  }, {
    id: "saved",
    label: "Shortlist",
    icon: window.IHeart
  }, {
    id: "profile",
    label: "Profile",
    icon: window.IUser
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-around",
      alignItems: "center",
      borderTop: "1px solid var(--border-subtle)",
      background: "var(--surface-card)",
      padding: "8px 8px 26px"
    }
  }, tabs.map(t => {
    const I = t.icon;
    const on = active === t.id;
    return /*#__PURE__*/React.createElement("button", {
      key: t.id,
      onClick: () => onChange(t.id),
      style: {
        border: "none",
        background: "none",
        cursor: "pointer",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 4,
        color: on ? "var(--color-brand)" : "var(--text-muted)",
        flex: 1,
        padding: "4px 0"
      }
    }, /*#__PURE__*/React.createElement(I, {
      size: 24,
      fill: on ? "var(--color-brand)" : "none"
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        fontWeight: 600,
        fontFamily: "var(--font-sans)"
      }
    }, t.label));
  }));
}

// ── Matches feed ─────────────────────────────────────────────
function MatchesScreen({
  onOpen,
  saved,
  onSave,
  onChangePrefs
}) {
  const [tab, setTab] = React.useState("Perfect");
  const listings = window.AL_LISTINGS;
  const filtered = listings.filter(l => tab === "Perfect" ? l.match === "perfect" : l.match === "flex");
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: "100%",
      display: "flex",
      flexDirection: "column",
      background: "var(--surface-page)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "8px 20px 12px",
      background: "var(--surface-card)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      letterSpacing: "0.06em",
      textTransform: "uppercase",
      color: "var(--color-brand)"
    }
  }, "Your matches"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 24,
      fontWeight: 700,
      color: "var(--text-heading)",
      letterSpacing: "-0.01em"
    }
  }, "Seattle, WA")), /*#__PURE__*/React.createElement(IconButton, {
    variant: "soft",
    label: "Adjust preferences",
    onClick: onChangePrefs
  }, /*#__PURE__*/React.createElement(window.ISliders, {
    size: 20
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement(SegmentedControl, {
    options: [{
      label: "Perfect Matches",
      value: "Perfect"
    }, {
      label: "Flex Matches",
      value: "Flex"
    }],
    value: tab,
    onChange: setTab
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: "auto",
      padding: "16px 20px 24px",
      display: "flex",
      flexDirection: "column",
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text-secondary)"
    }
  }, tab === "Perfect" ? "Listings with everything on your wishlist." : "Close to your wishlist — a few hidden gems."), filtered.map(l => /*#__PURE__*/React.createElement(ListingCard, _extends({
    key: l.id,
    width: "100%"
  }, l, {
    saved: !!saved[l.id],
    onSave: () => onSave(l.id),
    onClick: () => onOpen(l.id)
  })))));
}

// ── Listing detail ───────────────────────────────────────────
function ListingDetailScreen({
  listing,
  onBack,
  saved,
  onSave
}) {
  const [photo, setPhoto] = React.useState(0);
  const l = listing;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: "100%",
      display: "flex",
      flexDirection: "column",
      background: "var(--surface-card)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: "auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      aspectRatio: "4 / 3",
      background: "var(--al-gray-100)"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: l.photos[photo],
    alt: l.name,
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 14,
      left: 16,
      right: 16,
      display: "flex",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    variant: "glass",
    label: "Back",
    onClick: onBack
  }, /*#__PURE__*/React.createElement(window.IChevronLeft, {
    size: 20
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    variant: "glass",
    label: "Share"
  }, /*#__PURE__*/React.createElement(window.IShare, {
    size: 18
  })), /*#__PURE__*/React.createElement(IconButton, {
    variant: "glass",
    label: "Save",
    onClick: () => onSave(l.id)
  }, /*#__PURE__*/React.createElement(window.IHeart, {
    size: 20,
    fill: saved[l.id] ? "var(--color-brand)" : "none",
    stroke: saved[l.id] ? "var(--color-brand)" : "currentColor"
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      bottom: 14,
      left: 0,
      right: 0,
      display: "flex",
      justifyContent: "center",
      gap: 6
    }
  }, l.photos.map((_, i) => /*#__PURE__*/React.createElement("button", {
    key: i,
    onClick: () => setPhoto(i),
    style: {
      width: i === photo ? 22 : 7,
      height: 7,
      borderRadius: 999,
      border: "none",
      cursor: "pointer",
      background: i === photo ? "#fff" : "rgba(255,255,255,0.6)",
      transition: "all .2s"
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 64,
      left: 16
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    variant: l.match
  }, l.match === "perfect" ? "Perfect Match" : "Flex Match"))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "20px 20px 8px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "baseline"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 28,
      fontWeight: 700,
      color: "var(--text-heading)",
      letterSpacing: "-0.01em"
    }
  }, l.price, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 16,
      fontWeight: 500,
      color: "var(--text-secondary)"
    }
  }, "/mo")), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 4,
      fontWeight: 600,
      color: "var(--text-secondary)"
    }
  }, /*#__PURE__*/React.createElement(window.IStar, {
    size: 16,
    fill: "var(--al-orange)",
    stroke: "none"
  }), l.rating)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 18,
      fontWeight: 600,
      color: "var(--text-heading)",
      marginTop: 6
    }
  }, l.name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      color: "var(--text-secondary)",
      fontSize: 14,
      marginTop: 2
    }
  }, /*#__PURE__*/React.createElement(window.IMapPin, {
    size: 15
  }), l.address), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      marginTop: 16
    }
  }, [[window.IBed, `${l.beds} bed`], [window.IBath, `${l.baths} bath`], [window.IHome, `${l.sqft.toLocaleString()} sqft`]].map(([Ic, label], i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      border: "1px solid var(--border-subtle)",
      borderRadius: "var(--radius-md)",
      padding: "12px 8px",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 5,
      color: "var(--text-heading)"
    }
  }, /*#__PURE__*/React.createElement(Ic, {
    size: 20,
    stroke: "var(--color-brand)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 600
    }
  }, label)))), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 18,
      fontSize: 15,
      lineHeight: 1.55,
      color: "var(--text-primary)"
    }
  }, l.blurb), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      color: "var(--text-heading)",
      marginTop: 18,
      marginBottom: 10
    }
  }, "Amenities"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 8
    }
  }, l.tags.map(t => /*#__PURE__*/React.createElement(Badge, {
    key: t,
    variant: "brand",
    size: "lg"
  }, t))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      marginTop: 18,
      color: "var(--state-success)",
      fontSize: 14,
      fontWeight: 600
    }
  }, /*#__PURE__*/React.createElement(window.ICheck, {
    size: 18
  }), "Available ", l.available))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      padding: "14px 20px 28px",
      borderTop: "1px solid var(--border-subtle)",
      background: "var(--surface-card)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    iconLeft: /*#__PURE__*/React.createElement(window.ICalendar, {
      size: 18
    }),
    style: {
      flex: 1
    }
  }, "Tour"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    style: {
      flex: 2
    }
  }, "Check availability")));
}
Object.assign(window, {
  BottomNav,
  MatchesScreen,
  ListingDetailScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile_app/Screens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile_app/data.js
try { (() => {
// Shared fake listing data for the Apartment List mobile kit.
window.AL_LISTINGS = [{
  id: "eliot",
  name: "The Eliot",
  address: "Capitol Hill, Seattle",
  price: "$2,450",
  beds: 2,
  baths: 1,
  sqft: 920,
  match: "perfect",
  rating: 4.8,
  available: "Now",
  image: "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=900&q=80",
  photos: ["https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=900&q=80", "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=900&q=80", "https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=900&q=80"],
  tags: ["Pet friendly", "In-unit laundry", "Rooftop deck"],
  blurb: "Bright corner two-bedroom with skyline views, steps from Cal Anderson Park."
}, {
  id: "marlowe",
  name: "Marlowe Flats",
  address: "Ballard, Seattle",
  price: "$1,890",
  beds: 1,
  baths: 1,
  sqft: 680,
  match: "perfect",
  rating: 4.6,
  available: "Jul 1",
  image: "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=900&q=80",
  photos: ["https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=900&q=80", "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=900&q=80"],
  tags: ["Pet friendly", "Dishwasher", "Bike storage"],
  blurb: "Sunny one-bedroom with a chef's kitchen and a quiet, tree-lined street."
}, {
  id: "harbor",
  name: "Harborview Lofts",
  address: "Belltown, Seattle",
  price: "$3,100",
  beds: 2,
  baths: 2,
  sqft: 1100,
  match: "flex",
  rating: 4.7,
  available: "Now",
  image: "https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=900&q=80",
  photos: ["https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=900&q=80", "https://images.unsplash.com/photo-1484154218962-a197022b5858?w=900&q=80"],
  tags: ["Gym", "Concierge", "Parking"],
  blurb: "Open-plan loft with floor-to-ceiling windows and a sweeping water view."
}, {
  id: "juniper",
  name: "Juniper Court",
  address: "Fremont, Seattle",
  price: "$2,150",
  beds: 1,
  baths: 1,
  sqft: 740,
  match: "flex",
  rating: 4.4,
  available: "Aug 15",
  image: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=900&q=80",
  photos: ["https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=900&q=80"],
  tags: ["Courtyard", "Pet friendly", "Parking"],
  blurb: "Charming garden-level unit around a leafy shared courtyard."
}];
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile_app/data.js", error: String((e && e.message) || e) }); }

// ui_kits/mobile_app/ios-frame.jsx
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)

/* BEGIN USAGE */
// iOS.jsx — Simplified iOS 26 (Liquid Glass) device frame
// Based on the iOS 26 UI Kit + Figma status bar spec. No assets, no deps.
// Exports (to window): IOSDevice, IOSStatusBar, IOSNavBar, IOSGlassPill, IOSList, IOSListRow, IOSKeyboard
//
// Usage — wrap your screen content in <IOSDevice> to get the bezel, status bar
// and home indicator (props: title, dark, keyboard):
//
//   <IOSDevice title="Settings">
//     ...your screen content...
//   </IOSDevice>
//   <IOSDevice dark title="Search" keyboard>…</IOSDevice>
/* END USAGE */

// ─────────────────────────────────────────────────────────────
// Status bar
// ─────────────────────────────────────────────────────────────
function IOSStatusBar({
  dark = false,
  time = '9:41'
}) {
  const c = dark ? '#fff' : '#000';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 154,
      alignItems: 'center',
      justifyContent: 'center',
      padding: '21px 24px 19px',
      boxSizing: 'border-box',
      position: 'relative',
      zIndex: 20,
      width: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 22,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      paddingTop: 1.5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: '-apple-system, "SF Pro", system-ui',
      fontWeight: 590,
      fontSize: 17,
      lineHeight: '22px',
      color: c
    }
  }, time)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 22,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 7,
      paddingTop: 1,
      paddingRight: 1
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "19",
    height: "12",
    viewBox: "0 0 19 12"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0",
    y: "7.5",
    width: "3.2",
    height: "4.5",
    rx: "0.7",
    fill: c
  }), /*#__PURE__*/React.createElement("rect", {
    x: "4.8",
    y: "5",
    width: "3.2",
    height: "7",
    rx: "0.7",
    fill: c
  }), /*#__PURE__*/React.createElement("rect", {
    x: "9.6",
    y: "2.5",
    width: "3.2",
    height: "9.5",
    rx: "0.7",
    fill: c
  }), /*#__PURE__*/React.createElement("rect", {
    x: "14.4",
    y: "0",
    width: "3.2",
    height: "12",
    rx: "0.7",
    fill: c
  })), /*#__PURE__*/React.createElement("svg", {
    width: "17",
    height: "12",
    viewBox: "0 0 17 12"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M8.5 3.2C10.8 3.2 12.9 4.1 14.4 5.6L15.5 4.5C13.7 2.7 11.2 1.5 8.5 1.5C5.8 1.5 3.3 2.7 1.5 4.5L2.6 5.6C4.1 4.1 6.2 3.2 8.5 3.2Z",
    fill: c
  }), /*#__PURE__*/React.createElement("path", {
    d: "M8.5 6.8C9.9 6.8 11.1 7.3 12 8.2L13.1 7.1C11.8 5.9 10.2 5.1 8.5 5.1C6.8 5.1 5.2 5.9 3.9 7.1L5 8.2C5.9 7.3 7.1 6.8 8.5 6.8Z",
    fill: c
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "8.5",
    cy: "10.5",
    r: "1.5",
    fill: c
  })), /*#__PURE__*/React.createElement("svg", {
    width: "27",
    height: "13",
    viewBox: "0 0 27 13"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0.5",
    y: "0.5",
    width: "23",
    height: "12",
    rx: "3.5",
    stroke: c,
    strokeOpacity: "0.35",
    fill: "none"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "2",
    y: "2",
    width: "20",
    height: "9",
    rx: "2",
    fill: c
  }), /*#__PURE__*/React.createElement("path", {
    d: "M25 4.5V8.5C25.8 8.2 26.5 7.2 26.5 6.5C26.5 5.8 25.8 4.8 25 4.5Z",
    fill: c,
    fillOpacity: "0.4"
  }))));
}

// ─────────────────────────────────────────────────────────────
// Liquid glass pill — blur + tint + shine
// ─────────────────────────────────────────────────────────────
function IOSGlassPill({
  children,
  dark = false,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: 44,
      minWidth: 44,
      borderRadius: 9999,
      position: 'relative',
      overflow: 'hidden',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: dark ? '0 2px 6px rgba(0,0,0,0.35), 0 6px 16px rgba(0,0,0,0.2)' : '0 1px 3px rgba(0,0,0,0.07), 0 3px 10px rgba(0,0,0,0.06)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 9999,
      backdropFilter: 'blur(12px) saturate(180%)',
      WebkitBackdropFilter: 'blur(12px) saturate(180%)',
      background: dark ? 'rgba(120,120,128,0.28)' : 'rgba(255,255,255,0.5)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 9999,
      boxShadow: dark ? 'inset 1.5px 1.5px 1px rgba(255,255,255,0.15), inset -1px -1px 1px rgba(255,255,255,0.08)' : 'inset 1.5px 1.5px 1px rgba(255,255,255,0.7), inset -1px -1px 1px rgba(255,255,255,0.4)',
      border: dark ? '0.5px solid rgba(255,255,255,0.15)' : '0.5px solid rgba(0,0,0,0.06)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 1,
      display: 'flex',
      alignItems: 'center',
      padding: '0 4px'
    }
  }, children));
}

// ─────────────────────────────────────────────────────────────
// Navigation bar — glass pills + large title
// ─────────────────────────────────────────────────────────────
function IOSNavBar({
  title = 'Title',
  dark = false,
  trailingIcon = true
}) {
  const muted = dark ? 'rgba(255,255,255,0.6)' : '#404040';
  const text = dark ? '#fff' : '#000';
  const pillIcon = content => /*#__PURE__*/React.createElement(IOSGlassPill, {
    dark: dark
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 36,
      height: 36,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, content));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      paddingTop: 62,
      paddingBottom: 10,
      position: 'relative',
      zIndex: 5
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 16px'
    }
  }, pillIcon(/*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "20",
    viewBox: "0 0 12 20",
    fill: "none",
    style: {
      marginLeft: -1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M10 2L2 10l8 8",
    stroke: muted,
    strokeWidth: "2.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))), trailingIcon && pillIcon(/*#__PURE__*/React.createElement("svg", {
    width: "22",
    height: "6",
    viewBox: "0 0 22 6"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "3",
    cy: "3",
    r: "2.5",
    fill: muted
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "11",
    cy: "3",
    r: "2.5",
    fill: muted
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "19",
    cy: "3",
    r: "2.5",
    fill: muted
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px',
      fontFamily: '-apple-system, system-ui',
      fontSize: 34,
      fontWeight: 700,
      lineHeight: '41px',
      color: text,
      letterSpacing: 0.4
    }
  }, title));
}

// ─────────────────────────────────────────────────────────────
// Grouped list (inset card, r:26) + row (52px)
// ─────────────────────────────────────────────────────────────
function IOSListRow({
  title,
  detail,
  icon,
  chevron = true,
  isLast = false,
  dark = false
}) {
  const text = dark ? '#fff' : '#000';
  const sec = dark ? 'rgba(235,235,245,0.6)' : 'rgba(60,60,67,0.6)';
  const ter = dark ? 'rgba(235,235,245,0.3)' : 'rgba(60,60,67,0.3)';
  const sep = dark ? 'rgba(84,84,88,0.65)' : 'rgba(60,60,67,0.12)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      minHeight: 52,
      padding: '0 16px',
      position: 'relative',
      fontFamily: '-apple-system, system-ui',
      fontSize: 17,
      letterSpacing: -0.43
    }
  }, icon && /*#__PURE__*/React.createElement("div", {
    style: {
      width: 30,
      height: 30,
      borderRadius: 7,
      background: icon,
      marginRight: 12,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      color: text
    }
  }, title), detail && /*#__PURE__*/React.createElement("span", {
    style: {
      color: sec,
      marginRight: 6
    }
  }, detail), chevron && /*#__PURE__*/React.createElement("svg", {
    width: "8",
    height: "14",
    viewBox: "0 0 8 14",
    style: {
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M1 1l6 6-6 6",
    stroke: ter,
    strokeWidth: "2",
    fill: "none",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })), !isLast && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: 0,
      right: 0,
      left: icon ? 58 : 16,
      height: 0.5,
      background: sep
    }
  }));
}
function IOSList({
  header,
  children,
  dark = false
}) {
  const hc = dark ? 'rgba(235,235,245,0.6)' : 'rgba(60,60,67,0.6)';
  const bg = dark ? '#1C1C1E' : '#fff';
  return /*#__PURE__*/React.createElement("div", null, header && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: '-apple-system, system-ui',
      fontSize: 13,
      color: hc,
      textTransform: 'uppercase',
      padding: '8px 36px 6px',
      letterSpacing: -0.08
    }
  }, header), /*#__PURE__*/React.createElement("div", {
    style: {
      background: bg,
      borderRadius: 26,
      margin: '0 16px',
      overflow: 'hidden'
    }
  }, children));
}

// ─────────────────────────────────────────────────────────────
// Device frame
// ─────────────────────────────────────────────────────────────
function IOSDevice({
  children,
  width = 402,
  height = 874,
  dark = false,
  title,
  keyboard = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width,
      height,
      borderRadius: 48,
      overflow: 'hidden',
      position: 'relative',
      background: dark ? '#000' : '#F2F2F7',
      boxShadow: '0 40px 80px rgba(0,0,0,0.18), 0 0 0 1px rgba(0,0,0,0.12)',
      fontFamily: '-apple-system, system-ui, sans-serif',
      WebkitFontSmoothing: 'antialiased'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 11,
      left: '50%',
      transform: 'translateX(-50%)',
      width: 126,
      height: 37,
      borderRadius: 24,
      background: '#000',
      zIndex: 50
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      zIndex: 10
    }
  }, /*#__PURE__*/React.createElement(IOSStatusBar, {
    dark: dark
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      display: 'flex',
      flexDirection: 'column'
    }
  }, title !== undefined && /*#__PURE__*/React.createElement(IOSNavBar, {
    title: title,
    dark: dark
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: 'auto'
    }
  }, children), keyboard && /*#__PURE__*/React.createElement(IOSKeyboard, {
    dark: dark
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: 0,
      left: 0,
      right: 0,
      zIndex: 60,
      height: 34,
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'flex-end',
      paddingBottom: 8,
      pointerEvents: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 139,
      height: 5,
      borderRadius: 100,
      background: dark ? 'rgba(255,255,255,0.7)' : 'rgba(0,0,0,0.25)'
    }
  })));
}

// ─────────────────────────────────────────────────────────────
// Keyboard — iOS 26 liquid glass
// ─────────────────────────────────────────────────────────────
function IOSKeyboard({
  dark = false
}) {
  const glyph = dark ? 'rgba(255,255,255,0.7)' : '#595959';
  const sugg = dark ? 'rgba(255,255,255,0.6)' : '#333';
  const keyBg = dark ? 'rgba(255,255,255,0.22)' : 'rgba(255,255,255,0.85)';

  // special-key icons
  const icons = {
    shift: /*#__PURE__*/React.createElement("svg", {
      width: "19",
      height: "17",
      viewBox: "0 0 19 17"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M9.5 1L1 9.5h4.5V16h8V9.5H18L9.5 1z",
      fill: glyph
    })),
    del: /*#__PURE__*/React.createElement("svg", {
      width: "23",
      height: "17",
      viewBox: "0 0 23 17"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M7 1h13a2 2 0 012 2v11a2 2 0 01-2 2H7l-6-7.5L7 1z",
      fill: "none",
      stroke: glyph,
      strokeWidth: "1.6",
      strokeLinejoin: "round"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M10 5l7 7M17 5l-7 7",
      stroke: glyph,
      strokeWidth: "1.6",
      strokeLinecap: "round"
    })),
    ret: /*#__PURE__*/React.createElement("svg", {
      width: "20",
      height: "14",
      viewBox: "0 0 20 14"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M18 1v6H4m0 0l4-4M4 7l4 4",
      fill: "none",
      stroke: "#fff",
      strokeWidth: "1.8",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }))
  };
  const key = (content, {
    w,
    flex,
    ret,
    fs = 25,
    k
  } = {}) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      height: 42,
      borderRadius: 8.5,
      flex: flex ? 1 : undefined,
      width: w,
      minWidth: 0,
      background: ret ? '#08f' : keyBg,
      boxShadow: '0 1px 0 rgba(0,0,0,0.075)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: '-apple-system, "SF Compact", system-ui',
      fontSize: fs,
      fontWeight: 458,
      color: ret ? '#fff' : glyph
    }
  }, content);
  const row = (keys, pad = 0) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6.5,
      justifyContent: 'center',
      padding: `0 ${pad}px`
    }
  }, keys.map(l => key(l, {
    flex: true,
    k: l
  })));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 15,
      borderRadius: 27,
      overflow: 'hidden',
      padding: '11px 0 2px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      boxShadow: dark ? '0 -2px 20px rgba(0,0,0,0.09)' : '0 -1px 6px rgba(0,0,0,0.018), 0 -3px 20px rgba(0,0,0,0.012)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 27,
      backdropFilter: 'blur(12px) saturate(180%)',
      WebkitBackdropFilter: 'blur(12px) saturate(180%)',
      background: dark ? 'rgba(120,120,128,0.14)' : 'rgba(255,255,255,0.25)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 27,
      boxShadow: dark ? 'inset 1.5px 1.5px 1px rgba(255,255,255,0.15)' : 'inset 1.5px 1.5px 1px rgba(255,255,255,0.7), inset -1px -1px 1px rgba(255,255,255,0.4)',
      border: dark ? '0.5px solid rgba(255,255,255,0.15)' : '0.5px solid rgba(0,0,0,0.06)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 20,
      alignItems: 'center',
      padding: '8px 22px 13px',
      width: '100%',
      boxSizing: 'border-box',
      position: 'relative'
    }
  }, ['"The"', 'the', 'to'].map((w, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      width: 1,
      height: 25,
      background: '#ccc',
      opacity: 0.3
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      textAlign: 'center',
      fontFamily: '-apple-system, system-ui',
      fontSize: 17,
      color: sugg,
      letterSpacing: -0.43,
      lineHeight: '22px'
    }
  }, w)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 13,
      padding: '0 6.5px',
      width: '100%',
      boxSizing: 'border-box',
      position: 'relative'
    }
  }, row(['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p']), row(['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'], 20), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14.25,
      alignItems: 'center'
    }
  }, key(icons.shift, {
    w: 45,
    k: 'shift'
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6.5,
      flex: 1
    }
  }, ['z', 'x', 'c', 'v', 'b', 'n', 'm'].map(l => key(l, {
    flex: true,
    k: l
  }))), key(icons.del, {
    w: 45,
    k: 'del'
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      alignItems: 'center'
    }
  }, key('ABC', {
    w: 92.25,
    fs: 18,
    k: 'abc'
  }), key('', {
    flex: true,
    k: 'space'
  }), key(icons.ret, {
    w: 92.25,
    ret: true,
    k: 'ret'
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 56,
      width: '100%',
      position: 'relative'
    }
  }));
}
Object.assign(window, {
  IOSDevice,
  IOSStatusBar,
  IOSNavBar,
  IOSGlassPill,
  IOSList,
  IOSListRow,
  IOSKeyboard
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile_app/ios-frame.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.FilterChip = __ds_scope.FilterChip;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.SegmentedControl = __ds_scope.SegmentedControl;

__ds_ns.ListingCard = __ds_scope.ListingCard;

})();
