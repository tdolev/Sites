# Apartment List — Design System

A brand & product design system for **Apartment List**, the personalized apartment rental
marketplace. This project gives design agents the foundations (color, type, spacing), brand
assets (logos, house mark), reusable React components, and full-screen UI kits needed to
produce on-brand interfaces, marketing pages, decks, and prototypes.

---

## 1. Company & product context

**Apartment List** is a rental marketplace that replaces endless list-scrolling with a
guided, personalized match. Renters take a short **Rental Matchmaker quiz** (budget,
location, amenities, move-in date, lifestyle) and the product instantly returns curated
listings sorted into **Perfect Matches** (everything on the wishlist) and **Flex Matches**
(close-but-not-exact "hidden gems"). Renters swipe/approve listings into a **Shortlist**,
hit "Maybe" to save for later, browse a **map**, view rich **property detail** pages
(photos, virtual tours, live pricing, amenities, pet policy, fees), and **book tours** or
contact properties directly — 24/7. Real-time alerts notify on price drops and new
openings. The catalog spans millions of units across all 50 US states.

The experience is often likened to a "dating app for apartments": personal, opinionated,
guided, and time-saving (the brand claims to save renters 50+ hours of searching).

### Products / surfaces represented here
- **Mobile app** (iOS/Android) — the Matchmaker quiz, the Matches feed, swipe-to-shortlist,
  listing detail, tour booking.
- **Marketing website** — homepage hero, "how it works", value props, quiz entry point.

### Sources used to build this system
- `uploads/Apartment List Brand Guidelines v3.0-compressed.pdf` — *referenced in the brief
  but NOT present in the project filesystem.* Color values below come from the standalone
  Brand Color PDF; broader guideline details (logo clear-space, grids, photography) could
  not be read. **If you have the full guidelines PDF, please re-upload it.**
- `uploads/Brand Color (1).pdf` — official primary + secondary color palette (the source of
  truth for all color tokens).
- Logo & house-mark assets: `AList_Logo_RGB.png`, `Apartment_List_Logo_RGB.png`,
  `House-Original.svg`, `House-White.svg`, `House-On Purple.svg`, `HouseLogo_white_circle.png`,
  and EPS/PNG variants (copied into `assets/logos/`).
- Fonts: **Haffer XH** (Regular/Medium/SemiBold/Bold) and **Thunder SemiBold LC** —
  provided as OTF, copied into `assets/fonts/`.
- Product behavior & copy: Apartment List App Store / Google Play listings and the public
  renter FAQ (used for tone, feature names, and microcopy — see Content Fundamentals).

> **No codebase or Figma file was provided.** UI kits are brand-accurate recreations built
> from the documented product behavior and the brand assets above — not pixel captures of
> production screens. Treat them as faithful interpretations, not exact clones.

---

## 2. Content fundamentals — how Apartment List writes

**Voice:** warm, confident, human, and a little playful. It frames apartment hunting as an
emotional, sometimes overwhelming journey and positions Apartment List as the friendly
expert that makes it effortless.

- **Person:** Speaks to the renter as **"you"**, and refers to the product as **"we / our"**
  ("**we'll** instantly recommend…", "**our** Rental Matchmaker"). Collaborative and
  service-oriented.
- **Casing:** Sentence case for almost everything — headlines, buttons, nav. Feature names
  are Title Case proper nouns: **Rental Matchmaker**, **Perfect Matches**, **Flex Matches**,
  **Smart Matches**, **Shortlist**. UPPERCASE is reserved for tiny eyebrows/overlines.
- **Tone moves:**
  - Benefit-led and time-focused — "save 50+ hours of searching", "Search fast and rent faster."
  - Personalization is the hero — "the most personalized way to apartment hunt", "curated
    just for you", "apartments that actually match your lifestyle."
  - Reassuring and honest — "We don't skip out on the fine print – like pet policies and
    move-in fees – so you know exactly what to expect."
  - Light, encouraging verbs: *Discover, Tell us, Swipe right, Book, Get matched.*
- **Microcopy examples (verbatim-style):**
  - "Tell us what you want in your next home."
  - "Get personalized matches for apartments, condos, and houses for rent."
  - "Swipe right and we'll automatically add it to your shortlist."
  - "Hit *Maybe* on the listings you're not sure about — we'll save them for later."
  - "Perfect Matches: listings that have everything on your wishlist."
  - "Flex Matches: may not match everything, but you might find a few hidden gems."
- **Punctuation:** em dashes and ampersands are friendly and welcome. Exclamation points
  used sparingly for delight, never shouty.
- **Emoji:** Not part of the system UI. Avoid emoji in product chrome and marketing
  headlines. (Heart/save and map iconography are drawn as icons, not emoji.)
- **Numbers:** Concrete and confident — "6 million apartments", "all 50 states",
  "5-minute quiz", "50+ hours". Rent shown as `$2,450/mo`.

---

## 3. Visual foundations

### Color
- **Monochromatic purple core.** **Indigo Purple `#6105C4`** is the signature — "as important
  as our logo." **Darker Purple `#46137B`** anchors dense surfaces, inverse sections, and
  text-on-light headings. **Natural Oat `#F5F2ED`**, a warm off-white, is the default page
  canvas (not stark white) — it gives the brand its soft, premium warmth.
- **Secondary palette adds energy:** Light Purple `#C384F0` and Lavender `#DEC8FF` for soft
  fills/selected states; **Orange `#FF974D`** as a warm pop (Flex energy, highlights); **Red
  `#FF0029`** for alerts/urgency/price-drops. Text Black is `#333333` (true black is avoided).
- Use color generously but keep purple dominant; oranges/reds are accents, not fields.

### Type
- **Haffer XH** (a clean modern grotesque) is the workhorse: UI, body, most headings.
  Weights 400/500/600/700.
- **Thunder SemiBold LC** is a tall **condensed display** face for big expressive moments —
  hero headlines and large numerals. Set tight (line-height ~1.05, slightly negative
  tracking). Use sparingly; it's a spice, not the meal.
- Headings are tight and bold; body is 16px/1.5; eyebrows are uppercase Haffer with `0.06em`
  tracking in Indigo Purple.

### Shape, depth & surfaces
- **Generous rounding.** Buttons and chips are fully **pill-shaped** (`--radius-pill`).
  Cards use 16–24px radii; modals/large surfaces up to 32px. Friendly, never sharp.
- **Cards:** white surface on the oat canvas, soft low-contrast shadow (`--shadow-sm`/`md`),
  hairline `--border-subtle` only when shadow isn't enough separation. No heavy outlines, no
  colored left-border accent gimmicks.
- **Shadows** are soft, warm, and diffuse (tinted with the dark-plum ink at low alpha) — never
  hard black drop shadows. A dedicated `--shadow-brand` (purple-tinted) lifts primary CTAs.
- **Borders:** 1px hairlines in warm grays; 1.5px when a stronger edge is wanted.

### Backgrounds & imagery
- Page background is **Natural Oat**, occasionally a **full-bleed Indigo/Darker Purple**
  section for inverse moments (footers, hero bands, CTA blocks).
- **Photography is warm and lifestyle-led** — real apartments and real people, bright and
  inviting. Pair with the purple UI rather than tinting the photos. No heavy duotones, no
  grain, no b&w by default.
- The **house mark** (concentric house outline with an "L" and motion lines) is used as a
  watermark/brand stamp, often reversed white on purple or in its purple circle badge.

### Motion & interaction
- **Quick and eased, no bounce.** Transitions 120–320ms on `--ease-standard` / `--ease-out`.
  Fades and gentle slides; the swipe-to-shortlist gesture is the one signature motion.
- **Hover:** subtle — primary buttons deepen toward Darker Purple; ghost/secondary gain a
  faint lavender tint; cards lift one shadow step.
- **Press:** slight scale-down (~0.98) and a touch darker. Hit targets ≥ 44px on mobile.
- **Focus:** 2px Light-Purple ring, 2px offset.

### Layout
- Centered max-width containers (`--container-max: 1200px`, narrow `880px`). Comfortable
  white space; the oat canvas does a lot of the breathing work. Sticky top header (72px).

---

## 4. Iconography

- No production icon set was available in the brief, so the system standardizes on
  **Lucide** (https://lucide.dev) via CDN — a clean, rounded, **2px-stroke outline** set whose
  geometry and friendliness match Haffer and the rounded UI. *(Substitution flagged: if
  Apartment List ships a proprietary icon font/SVG set, swap it in and update this section.)*
- **Style rules:** outline (stroke) icons, 2px stroke, rounded caps/joins, 24px default box.
  Color icons with `currentColor` so they inherit text/brand color. Use Indigo Purple for
  active/brand icons, gray-500 for default, white on purple surfaces.
- **The house mark** (`assets/logos/house-mark*.svg`) is brand iconography, not a UI icon —
  use it for app icons, badges, watermarks, and empty-states, not inline with text.
- **Emoji / unicode are not used as icons.** Always use Lucide SVGs or the house mark.
- Load via CDN: `<script src="https://unpkg.com/lucide@latest"></script>` then
  `lucide.createIcons()`, or use individual SVGs.

---

## 5. Index / manifest

**Root**
- `styles.css` — global entry point (import lines only). Consumers link this.
- `readme.md` — this guide.
- `SKILL.md` — Agent-Skill front matter for use in Claude Code.

**Tokens** (`tokens/`)
- `fonts.css` — `@font-face` for Haffer XH + Thunder.
- `colors.css` — primary/secondary palette, neutral + purple ramps, semantic aliases.
- `typography.css` — families, weights, scale, line-heights, roles.
- `spacing.css` — spacing scale, radii, shadows, motion, layout.
- `base.css` — element defaults + `.al-display` / `.al-eyebrow` utilities.

**Foundations cards** (`guidelines/`) — specimen cards shown in the Design System tab
(Type, Colors, Spacing, Brand).

**Components** (`components/`) — reusable React primitives, exposed on
`window.ApartmentListDesignSystem_9ce450`. Each has a `.jsx`, `.d.ts`, and `.prompt.md`.
- `core/` — `Button`, `Badge`, `Input`, `Card`, `Avatar`, `FilterChip`, `IconButton`,
  `SegmentedControl`.
- `product/` — `ListingCard` (the signature property card; composes Badge + IconButton).

**UI kits** (`ui_kits/`)
- `mobile_app/` — Apartment List app surfaces (Matchmaker, Matches, Listing detail).
- `marketing_site/` — homepage / how-it-works marketing surface.

**Assets** (`assets/`)
- `fonts/` — Haffer XH + Thunder OTFs.
- `logos/` — wordmark + house-mark variants (color, white, on-purple, circle badge, black).

---

*Caveats: full brand guidelines PDF and any production codebase/Figma were not available;
color is authoritative, but logo clear-space rules, official photography direction, and the
production icon set are inferred. See the closing notes for the iterate ask.*
