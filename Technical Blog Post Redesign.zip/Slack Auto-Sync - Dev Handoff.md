# Slack → Blog Auto-Sync — Dev Handoff

## What the prototype shows
The header has a "Synced Xh ago" control and a pending-review queue (badge → modal → Approve & publish / Discard). This simulates the intended flow client-side — it does not talk to Slack. Real posts should land in that same pending state before going live; Slack messages are rarely publish-ready as typed.

## What's needed to make it real

**1. Slack app**
- Create a Slack app in the AL workspace, install it in #ai-nurture-tech-talks (channel ID `C085ZPFCUJV`).
- Events API subscription: `message.channels` (or `link_shared` if you only care about link posts).
- Bot scopes: `channels:history`, `channels:read`, `links:read`.

**2. Ingestion endpoint**
- A webhook receives the Slack event payload and verifies it against the Slack signing secret.
- Slack usually unfurls links server-side already — `message.attachments[]` often has `title`, `text`, `image_url` pulled from the page's OG tags. Use that first; only fetch OG tags yourself as a fallback (e.g. private links Slack didn't unfurl).

**3. Parsing → post record**
- Map the message + unfurl data to the existing post schema (`posts-data.js`): `{id, date, author, tags, emoji, title, summary, body, link}`.
- `author`: resolve Slack user ID → display name via `users.info`.
- `tags` / `title` / `summary`: keyword-match against the current tag vocabulary, or use an LLM call (Claude) fed the message text + unfurled title/description to produce a title/summary/tags in house style.
- `date`: message timestamp.

**4. Human review (recommended, matches the prototype)**
- New posts land in a pending state, not published directly.
- Reuse this UI's pattern: pending list with Approve / Discard (Edit could be added later).
- Approve promotes the record to the real published data store; Discard drops it.

**5. Data storage**
- `posts-data.js` is a static file — fine for a prototype, not for live writes.
- Simplest real path: Approve triggers a commit (or opens a PR) that appends the record to a JSON file in the repo, then the site rebuilds. No DB needed for a few posts a week.
- If approvals need to work without a redeploy, move to a small datastore (Airtable, Notion API, or a Postgres table) the frontend fetches from instead of the static script.

**6. Frontend**
- Either keep it fully static (rebuild on approve) or swap `<script src="posts-data.js">` for a fetch against the new data source.
- The pending queue should live behind internal auth — it's a drafts view, not public.

## Suggested v1 scope
Slack event → webhook → LLM-assisted draft → pending queue (this UI, or a bot DM with buttons) → on approve, commit to a JSON file → redeploy. Skip a DB for v1.

## Open questions
- Published data: static file + rebuild, or a real datastore?
- Who approves — anyone who posts, or a designated curator?
- Approve from this UI, or directly in Slack via bot buttons?
